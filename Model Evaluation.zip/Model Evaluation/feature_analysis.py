#!/usr/bin/env python3
"""
Feature Analysis and Selection for CatBoost Model

This script performs comprehensive feature importance analysis and feature selection
optimization for restaurant demand forecasting using CatBoost.

Features:
1. Generate feature importance visualization
2. Identify and remove low-impact features
3. Retrain model with selected features
4. Compare performance metrics before and after feature selection
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from catboost import CatBoostRegressor
import warnings
import time
import joblib
from unified_restaurant_demand_system import RestaurantFeatureEngineer

warnings.filterwarnings('ignore')

class FeatureAnalyzer:
    """
    Comprehensive feature analysis and selection for CatBoost model.
    """
    
    def __init__(self, data_path, random_state=42):
        """
        Initialize the feature analyzer.
        
        Args:
            data_path (str): Path to the dataset
            random_state (int): Random seed for reproducibility
        """
        self.data_path = data_path
        self.random_state = random_state
        self.feature_engineer = RestaurantFeatureEngineer(data_path)
        self.original_model = None
        self.optimized_model = None
        self.feature_importance_df = None
        self.selected_features = None
        self.results = {}
        
        # Set random seeds
        np.random.seed(random_state)
        
    def prepare_data(self):
        """
        Prepare the dataset with feature engineering.
        
        Returns:
            tuple: X_train, X_test, y_train, y_test, feature_columns
        """
        print("=== DATA PREPARATION ===")
        
        # Load and engineer features
        df = self.feature_engineer.engineer_features_for_existing_items()
        
        # Select features for modeling
        feature_columns = [
            # Historical demand features
            'lag_1_day', 'lag_7_day', 'ma_7_day', 'ma_30_day', 'std_7_day', 'trend_7_day',
            
            # Price features
            'price_gap', 'profit_margin', 'price_to_cost_ratio', 'market_price_ratio', 'price_rank_in_category',
            
            # Categorical features (encoded)
            'category_encoded', 'cuisine_type_encoded', 'meal_type_encoded', 'restaurant_type_encoded',
            'ingredient_count',
            
            # Contextual features
            'day_of_week_num', 'day_sin', 'day_cos', 'month', 'month_sin', 'month_cos',
            'is_weekend', 'weekend_lunch', 'weekend_dinner',
            
            # Restaurant features
            'restaurant_demand_mean', 'restaurant_demand_std',
            
            # Interaction features
            'price_special_event', 'price_promotion', 'price_weekend',
            'category_restaurant_interaction', 'meal_day_interaction'
        ]
        
        # Filter features that exist in the dataset
        available_features = [col for col in feature_columns if col in df.columns]
        print(f"Using {len(available_features)} features for modeling")
        
        # Prepare features and target
        X = df[available_features].fillna(0)
        y = df['demand']
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=None
        )
        
        print(f"Training set: {X_train.shape[0]} samples")
        print(f"Test set: {X_test.shape[0]} samples")
        print(f"Features: {X_train.shape[1]}")
        
        return X_train, X_test, y_train, y_test, available_features
    
    def train_original_model(self, X_train, y_train):
        """
        Train the original CatBoost model with all features.
        
        Args:
            X_train: Training features
            y_train: Training target
        """
        print("\n=== TRAINING ORIGINAL MODEL ===")
        
        # Use optimized parameters from previous tuning
        self.original_model = CatBoostRegressor(
            iterations=340,
            depth=10,
            learning_rate=0.1,
            l2_leaf_reg=3,
            border_count=64,
            bagging_temperature=0,
            random_seed=self.random_state,
            thread_count=-1,
            verbose=False,
            loss_function='RMSE'
        )
        
        # Train the model
        start_time = time.time()
        self.original_model.fit(X_train, y_train)
        training_time = time.time() - start_time
        
        print(f"Original model trained in {training_time:.2f} seconds")
        
    def analyze_feature_importance(self, X_train):
        """
        Analyze feature importance and create visualization.
        
        Args:
            X_train: Training features
        """
        print("\n=== FEATURE IMPORTANCE ANALYSIS ===")
        
        # Get feature importance
        self.feature_importance_df = pd.DataFrame({
            'feature': X_train.columns,
            'importance': self.original_model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        # Calculate importance percentages
        total_importance = self.feature_importance_df['importance'].sum()
        self.feature_importance_df['importance_pct'] = (
            self.feature_importance_df['importance'] / total_importance * 100
        )   
        print("\nTop 10 Most Important Features:")
        print("-" * 50)
        for i, (_, row) in enumerate(self.feature_importance_df.head(10).iterrows(), 1):
            print(f"{i:2d}. {row['feature']:<25}: {row['importance_pct']:.3f}%")
        
        # Create feature importance visualization
        self.create_feature_importance_plot()
        
    def create_feature_importance_plot(self):
        """
        Create and save feature importance visualization.
        """
        print("\nCreating feature importance visualization...")
        
        # Set up the plot
        plt.figure(figsize=(12, 8))
        
        # Create horizontal bar plot
        colors = plt.cm.viridis(np.linspace(0, 1, len(self.feature_importance_df)))
        bars = plt.barh(range(len(self.feature_importance_df)), 
                       self.feature_importance_df['importance_pct'],
                       color=colors)
        
        # Customize the plot
        plt.yticks(range(len(self.feature_importance_df)), 
                  self.feature_importance_df['feature'])
        plt.xlabel('Feature Importance (%)', fontsize=12, fontweight='bold')
        plt.ylabel('Features', fontsize=12, fontweight='bold')
        plt.title('CatBoost Feature Importance Analysis\nRestaurant Demand Forecasting', 
                 fontsize=14, fontweight='bold', pad=20)
        
        # Add value labels on bars
        for i, (bar, pct) in enumerate(zip(bars, self.feature_importance_df['importance_pct'])):
            if pct > 1.0:  # Only show labels for features with >1% importance
                plt.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2, 
                        f'{pct:.2f}%', ha='left', va='center', fontsize=9)
        
        # Add grid for better readability
        plt.grid(axis='x', alpha=0.3, linestyle='--')
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('feature_importance.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print("Feature importance plot saved as 'feature_importance.png'")
        
    def identify_low_impact_features(self, threshold=0.1):
        """Identify features with importance below the threshold.    
        Args: threshold (float): Importance threshold percentage (default: 0.1%)         
        Returns: tuple: (selected_features, removed_features)
        """
        print(f"\n=== IDENTIFYING LOW-IMPACT FEATURES (< {threshold}%) ===")     
        # Identify features to remove
        low_impact_features = self.feature_importance_df[
            self.feature_importance_df['importance_pct'] < threshold
        ]['feature'].tolist()
        
        # Select features to keep
        self.selected_features = self.feature_importance_df[
            self.feature_importance_df['importance_pct'] >= threshold
        ]['feature'].tolist()
        
        print(f"Features to remove ({len(low_impact_features)}):")
        for feature in low_impact_features:
            importance = self.feature_importance_df[
                self.feature_importance_df['feature'] == feature
            ]['importance_pct'].iloc[0]
            print(f"  - {feature:<25}: {importance:.4f}%")
        
        print(f"\nFeatures to keep ({len(self.selected_features)}):")
        for feature in self.selected_features[:5]:  # Show top 5
            importance = self.feature_importance_df[
                self.feature_importance_df['feature'] == feature
            ]['importance_pct'].iloc[0]
            print(f"  - {feature:<25}: {importance:.3f}%")
        if len(self.selected_features) > 5:
            print(f"  ... and {len(self.selected_features) - 5} more features")
        
        return self.selected_features, low_impact_features
    
    def train_optimized_model(self, X_train, y_train):
        """
        Train CatBoost model with selected features only.
        
        Args:
            X_train: Training features
            y_train: Training target
        """
        print("\n=== TRAINING OPTIMIZED MODEL ===")
        
        # Filter training data to selected features
        X_train_selected = X_train[self.selected_features]
        
        # Use same parameters as original model
        self.optimized_model = CatBoostRegressor(
            iterations=340,
            depth=10,
            learning_rate=0.1,
            l2_leaf_reg=3,
            border_count=64,
            bagging_temperature=0,
            random_seed=self.random_state,
            thread_count=-1,
            verbose=False,
            loss_function='RMSE'
        )
        
        # Train the model
        start_time = time.time()
        self.optimized_model.fit(X_train_selected, y_train)
        training_time = time.time() - start_time
        
        print(f"Optimized model trained in {training_time:.2f} seconds")
        print(f"Feature reduction: {len(X_train.columns)} → {len(self.selected_features)} features")
        
    def calculate_mape(self, y_true, y_pred):
        """
        Calculate Mean Absolute Percentage Error.
        
        Args:
            y_true: True values
            y_pred: Predicted values
            
        Returns:
            float: MAPE value
        """
        return np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    def evaluate_models(self, X_train, X_test, y_train, y_test):
        """
        Evaluate and compare both models.
        
        Args:
            X_train, X_test: Training and test features
            y_train, y_test: Training and test targets
        """
        print("\n=== MODEL EVALUATION AND COMPARISON ===")
        
        # Prepare data for optimized model
        X_train_selected = X_train[self.selected_features]
        X_test_selected = X_test[self.selected_features]
        
        # Original model predictions
        y_train_pred_orig = self.original_model.predict(X_train)
        y_test_pred_orig = self.original_model.predict(X_test)
        
        # Optimized model predictions
        y_train_pred_opt = self.optimized_model.predict(X_train_selected)
        y_test_pred_opt = self.optimized_model.predict(X_test_selected)
        
        # Calculate metrics for original model
        orig_metrics = {
            'train_r2': r2_score(y_train, y_train_pred_orig),
            'test_r2': r2_score(y_test, y_test_pred_orig),
            'train_rmse': np.sqrt(mean_squared_error(y_train, y_train_pred_orig)),
            'test_rmse': np.sqrt(mean_squared_error(y_test, y_test_pred_orig)),
            'train_mae': mean_absolute_error(y_train, y_train_pred_orig),
            'test_mae': mean_absolute_error(y_test, y_test_pred_orig),
            'train_mape': self.calculate_mape(y_train, y_train_pred_orig),
            'test_mape': self.calculate_mape(y_test, y_test_pred_orig)
        }
        
        # Calculate metrics for optimized model
        opt_metrics = {
            'train_r2': r2_score(y_train, y_train_pred_opt),
            'test_r2': r2_score(y_test, y_test_pred_opt),
            'train_rmse': np.sqrt(mean_squared_error(y_train, y_train_pred_opt)),
            'test_rmse': np.sqrt(mean_squared_error(y_test, y_test_pred_opt)),
            'train_mae': mean_absolute_error(y_train, y_train_pred_opt),
            'test_mae': mean_absolute_error(y_test, y_test_pred_opt),
            'train_mape': self.calculate_mape(y_train, y_train_pred_opt),
            'test_mape': self.calculate_mape(y_test, y_test_pred_opt)
        }
        
        # Cross-validation scores
        cv_scores_orig = cross_val_score(
            self.original_model, X_train, y_train, cv=3, scoring='r2', n_jobs=-1
        )
        cv_scores_opt = cross_val_score(
            self.optimized_model, X_train_selected, y_train, cv=3, scoring='r2', n_jobs=-1
        )
        
        orig_metrics['cv_r2_mean'] = cv_scores_orig.mean()
        orig_metrics['cv_r2_std'] = cv_scores_orig.std()
        opt_metrics['cv_r2_mean'] = cv_scores_opt.mean()
        opt_metrics['cv_r2_std'] = cv_scores_opt.std()
        
        # Store results
        self.results = {
            'original_features': len(X_train.columns),
            'selected_features': len(self.selected_features),
            'feature_reduction_pct': (1 - len(self.selected_features) / len(X_train.columns)) * 100,
            'original_metrics': orig_metrics,
            'optimized_metrics': opt_metrics
        }
        
        # Print comparison
        self.print_comparison()
        
    def print_comparison(self):
        """
        Print detailed comparison of model performance.
        """
        orig = self.results['original_metrics']
        opt = self.results['optimized_metrics']
        
        print("\nMODEL PERFORMANCE COMPARISON")
        print("=" * 60)
        print(f"{'Metric':<20} {'Original':<15} {'Optimized':<15} {'Change':<10}")
        print("-" * 60)
        
        metrics = ['test_r2', 'test_rmse', 'test_mae', 'test_mape']
        metric_names = ['R² Score', 'RMSE', 'MAE', 'MAPE (%)']
        
        for metric, name in zip(metrics, metric_names):
            orig_val = orig[metric]
            opt_val = opt[metric]
            
            if metric == 'test_r2':
                change = opt_val - orig_val
                change_str = f"+{change:.4f}" if change >= 0 else f"{change:.4f}"
            else:
                change = ((opt_val - orig_val) / orig_val) * 100
                change_str = f"+{change:.2f}%" if change >= 0 else f"{change:.2f}%"
            
            print(f"{name:<20} {orig_val:<15.4f} {opt_val:<15.4f} {change_str:<10}")
        
        print("-" * 60)
        print(f"Features: {self.results['original_features']} → {self.results['selected_features']} "
              f"({self.results['feature_reduction_pct']:.1f}% reduction)")
        
    def generate_report(self):
        """
        Generate comprehensive feature selection report.
        """
        print("\n=== GENERATING FEATURE SELECTION REPORT ===")
        
        report_content = []
        report_content.append("FEATURE SELECTION ANALYSIS REPORT")
        report_content.append("=" * 50)
        report_content.append(f"Generated on: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        report_content.append(f"Dataset: {self.data_path}")
        report_content.append("")
        
        # Feature reduction summary
        report_content.append("FEATURE REDUCTION SUMMARY")
        report_content.append("-" * 30)
        report_content.append(f"Original features: {self.results['original_features']}")
        report_content.append(f"Selected features: {self.results['selected_features']}")
        report_content.append(f"Reduction: {self.results['feature_reduction_pct']:.1f}%")
        report_content.append("")
        
        # Performance comparison
        report_content.append("PERFORMANCE COMPARISON")
        report_content.append("-" * 25)
        orig = self.results['original_metrics']
        opt = self.results['optimized_metrics']
        
        report_content.append(f"{'Metric':<20} {'Original':<15} {'Optimized':<15} {'Change':<15}")
        report_content.append("-" * 65)
        
        metrics = [('test_r2', 'R² Score'), ('test_rmse', 'RMSE'), 
                  ('test_mae', 'MAE'), ('test_mape', 'MAPE (%)')]
        
        for metric, name in metrics:
            orig_val = orig[metric]
            opt_val = opt[metric]
            
            if metric == 'test_r2':
                change = opt_val - orig_val
                change_str = f"+{change:.4f}" if change >= 0 else f"{change:.4f}"
            else:
                change = ((opt_val - orig_val) / orig_val) * 100
                change_str = f"+{change:.2f}%" if change >= 0 else f"{change:.2f}%"
            
            report_content.append(f"{name:<20} {orig_val:<15.4f} {opt_val:<15.4f} {change_str:<15}")
        
        report_content.append("")
        
        # Cross-validation results
        report_content.append("CROSS-VALIDATION RESULTS")
        report_content.append("-" * 28)
        report_content.append(f"Original Model CV R²: {orig['cv_r2_mean']:.4f} ± {orig['cv_r2_std']:.4f}")
        report_content.append(f"Optimized Model CV R²: {opt['cv_r2_mean']:.4f} ± {opt['cv_r2_std']:.4f}")
        report_content.append("")
        
        # Feature importance details
        report_content.append("FEATURE IMPORTANCE ANALYSIS")
        report_content.append("-" * 31)
        report_content.append("Top 10 Most Important Features:")
        for i, (_, row) in enumerate(self.feature_importance_df.head(10).iterrows(), 1):
            report_content.append(f"{i:2d}. {row['feature']:<25}: {row['importance_pct']:.3f}%")
        
        report_content.append("")
        report_content.append("Removed Features (< 0.1% importance):")
        removed_features = self.feature_importance_df[
            self.feature_importance_df['importance_pct'] < 0.1
        ]
        for _, row in removed_features.iterrows():
            report_content.append(f"  - {row['feature']:<25}: {row['importance_pct']:.4f}%")
        
        # Conclusions
        report_content.append("")
        report_content.append("CONCLUSIONS")
        report_content.append("-" * 15)
        
        r2_change = opt['test_r2'] - orig['test_r2']
        if r2_change >= 0:
            report_content.append(f"✓ Feature selection maintained/improved performance (+{r2_change:.4f} R²)")
        else:
            report_content.append(f"⚠ Feature selection slightly reduced performance ({r2_change:.4f} R²)")
        
        report_content.append(f"✓ Reduced model complexity by {self.results['feature_reduction_pct']:.1f}%")
        report_content.append("✓ Improved training efficiency and interpretability")
        
        if abs(r2_change) < 0.01:
            report_content.append("✓ Negligible performance impact - feature selection successful")
        
        # Write report to file
        with open('feature_selection_report.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_content))
        
        print("Feature selection report saved as 'feature_selection_report.txt'")
        
    def run_complete_analysis(self):
        """
        Run the complete feature analysis pipeline.
        
        Returns:
            dict: Analysis results
        """
        print("STARTING COMPREHENSIVE FEATURE ANALYSIS")
        print("=" * 50)
        
        # Step 1: Prepare data
        X_train, X_test, y_train, y_test, feature_columns = self.prepare_data()
        
        # Step 2: Train original model
        self.train_original_model(X_train, y_train)
        
        # Step 3: Analyze feature importance
        self.analyze_feature_importance(X_train)
        
        # Step 4: Identify low-impact features
        selected_features, removed_features = self.identify_low_impact_features()
        
        # Step 5: Train optimized model
        self.train_optimized_model(X_train, y_train)
        
        # Step 6: Evaluate and compare models
        self.evaluate_models(X_train, X_test, y_train, y_test)
        
        # Step 7: Generate comprehensive report
        self.generate_report()
        
        print("\n" + "=" * 50)
        print("FEATURE ANALYSIS COMPLETED SUCCESSFULLY!")
        print("=" * 50)
        print("Generated files:")
        print("  - feature_importance.png (visualization)")
        print("  - feature_selection_report.txt (detailed report)")
        
        return self.results

def main():
    """
    Main function to run the feature analysis.
    """
    # Initialize analyzer
    data_path = "cleaned_streamlined_ultimate_malaysian_data.csv"
    analyzer = FeatureAnalyzer(data_path, random_state=42)
    
    # Run complete analysis
    results = analyzer.run_complete_analysis()
    
    # Print final summary
    print(f"\nFINAL SUMMARY:")
    print(f"Original R² Score: {results['original_metrics']['test_r2']:.4f}")
    print(f"Optimized R² Score: {results['optimized_metrics']['test_r2']:.4f}")
    print(f"Feature Reduction: {results['feature_reduction_pct']:.1f}%")

if __name__ == "__main__":
    main()