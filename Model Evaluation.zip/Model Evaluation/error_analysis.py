#!/usr/bin/env python3
"""
CatBoost Model Error Analysis Script for Restaurant Demand Prediction

This script provides comprehensive error analysis capabilities for the finalized CatBoost model including:
- Prediction error distribution analysis
- Error patterns by features
- Residual analysis
- Error visualization
- Model performance metrics

Author: AI Assistant
Date: 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
import joblib
import warnings
from pathlib import Path
import json
from datetime import datetime
import sys
import os

warnings.filterwarnings('ignore')

class FinalErrorAnalyzer:
    """
    CatBoost model error analysis for restaurant demand prediction
    """
    
    def __init__(self, data_path='cleaned_streamlined_ultimate_malaysian_data.csv'):
        """
        Initialize the Error Analyzer
        
        Args:
            data_path (str): Path to the dataset
        """
        self.data_path = data_path
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.models = {}
        self.feature_engineers = {}
        self.predictions = {}
        self.errors = {}
        
    def load_data(self):
        """
        Load and prepare the dataset
        """
        print("Loading dataset...")
        self.data = pd.read_csv(self.data_path)
        print(f"Dataset loaded: {self.data.shape[0]} rows, {self.data.shape[1]} columns")
        
        # Use feature engineering to prepare data (same as CatBoost training)
        from unified_restaurant_demand_system import RestaurantFeatureEngineer
        
        feature_engineer = RestaurantFeatureEngineer(self.data_path)
        df = feature_engineer.engineer_features_for_existing_items()
        
        # Select the same features used in CatBoost training
        feature_columns = [
            # Historical demand features
            'lag_1_day', 'lag_7_day', 'ma_7_day', 'ma_30_day', 'std_7_day', 'trend_7_day',
            
            # Price features
            'price_gap', 'profit_margin', 'price_to_cost_ratio', 'market_price_ratio', 'price_rank_in_category',
            
            # Categorical features (encoded)
            'category_encoded', 'cuisine_type_encoded', 'meal_type_encoded', 'restaurant_type_encoded',
            'ingredient_count',
            
            # Contextual features
            'day_of_week_num', 'day_sin', 'day_cos', 'month', 'month_sin', 'month_cos',
            'is_weekend', 'weekend_lunch', 'weekend_dinner',
            
            # Restaurant features
            'restaurant_demand_mean', 'restaurant_demand_std',
            
            # Interaction features
            'price_special_event', 'price_promotion', 'price_weekend',
            'category_restaurant_interaction', 'meal_day_interaction'
        ]
        
        # Filter features that exist in the dataset
        available_features = [col for col in feature_columns if col in df.columns]
        print(f"Using {len(available_features)} features for analysis")
        
        # Prepare features and target
        X = df[available_features].fillna(0)
        y = df['demand']
        
        # Split the data with the same random state as training
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        print(f"Training set: {self.X_train.shape[0]} samples")
        print(f"Test set: {self.X_test.shape[0]} samples")
        
    def load_models(self):
        """
        Load the finalized CatBoost model
        """
        print("\nLoading finalized CatBoost model...")
        model_files = {
            'CatBoost': 'catboost_tuned_model_*.joblib'
        }
        
        for model_name, pattern in model_files.items():
            model_path = self._find_latest_model(pattern)
            if model_path:
                try:
                    loaded_data = joblib.load(model_path)
                    # Extract the actual model and feature engineer from the dictionary
                    if isinstance(loaded_data, dict) and 'model' in loaded_data:
                        self.models[model_name] = loaded_data['model']
                        if 'feature_engineer' in loaded_data:
                            self.feature_engineers[model_name] = loaded_data['feature_engineer']
                    else:
                        self.models[model_name] = loaded_data
                    print(f"Loaded {model_name}: {model_path}")
                except Exception as e:
                    print(f"Failed to load {model_name}: {e}")
            else:
                print(f"No model found for {model_name}")
                
        if not self.models:
            raise ValueError("No CatBoost model found! Please ensure the CatBoost model is trained and saved.")
                
    def _find_latest_model(self, pattern):
        """
        Find the latest model file matching the pattern
        """
        import glob
        files = glob.glob(pattern)
        if files:
            return max(files, key=lambda x: Path(x).stat().st_mtime)
        return None
        
    def generate_predictions(self):
        """
        Generate predictions for all loaded models with proper shape handling
        """
        print("\nGenerating predictions...")
        for model_name, model in self.models.items():
            try:
                print(f"\nProcessing {model_name}...")
                
                # Use the preprocessed test data (features already engineered)
                X_test_filled = self.X_test.fillna(0)
                y_pred = model.predict(X_test_filled)
                
                # Ensure predictions match test set size
                if len(y_pred) != len(self.y_test):
                    y_pred = y_pred[:len(self.y_test)]
                
                self.predictions[model_name] = y_pred
                y_test_values = self.y_test.values if hasattr(self.y_test, 'values') else self.y_test
                errors = y_test_values - y_pred
                self.errors[model_name] = errors
                print(f"Generated predictions for {model_name} using engineered features")
                    
            except Exception as e:
                print(f"Failed to generate predictions for {model_name}: {e}")
                import traceback
                traceback.print_exc()
                
    def calculate_error_metrics(self):
        print("\nCalculating error metrics...")
        metrics_data = []
        
        if not self.predictions:
            print("No successful predictions found!")
            self.metrics_df = pd.DataFrame()
            return self.metrics_df
        
        for model_name in self.predictions.keys():
            if model_name not in self.errors:
                print(f"Skipping {model_name} - no error data available")
                continue
                
            try:
                y_pred = self.predictions[model_name]
                errors = self.errors[model_name]
                y_test_values = self.y_test.values if hasattr(self.y_test, 'values') else self.y_test
                
                # Ensure all arrays have the same length
                min_length = min(len(y_test_values), len(y_pred), len(errors))
                y_test_trimmed = y_test_values[:min_length]
                y_pred_trimmed = y_pred[:min_length]
                errors_trimmed = errors[:min_length]
                
                metrics = {
                    'Model': model_name,
                    'RMSE': np.sqrt(mean_squared_error(y_test_trimmed, y_pred_trimmed)),
                    'MAE': mean_absolute_error(y_test_trimmed, y_pred_trimmed),
                    'R²': r2_score(y_test_trimmed, y_pred_trimmed),
                    'Mean_Error': np.mean(errors_trimmed),
                    'Std_Error': np.std(errors_trimmed),
                    'Max_Error': np.max(np.abs(errors_trimmed)),
                    'Error_Range': np.max(errors_trimmed) - np.min(errors_trimmed),
                    'Q1_Error': np.percentile(errors_trimmed, 25),
                    'Q3_Error': np.percentile(errors_trimmed, 75),
                    'IQR_Error': np.percentile(errors_trimmed, 75) - np.percentile(errors_trimmed, 25)
                }
                
                metrics_data.append(metrics)
                print(f"Calculated metrics for {model_name}")
                
            except Exception as e:
                print(f"Failed to calculate metrics for {model_name}: {e}")
                
        self.metrics_df = pd.DataFrame(metrics_data)
        
        if not self.metrics_df.empty:
            print("\nError Metrics Summary:")
            print(self.metrics_df.round(4))
        else:
            print("No metrics calculated successfully!")
        
        return self.metrics_df
        
    def analyze_error_patterns(self):
        """
        Analyze error patterns across different features
        """
        print("\nAnalyzing error patterns...")
        
        if self.metrics_df.empty:
            print("No metrics available for error pattern analysis!")
            return None, None
        
        # Use CatBoost model for detailed analysis
        best_model = 'CatBoost'
        print(f"Using {best_model} for detailed error analysis")
        
        best_errors = self.errors[best_model]
        best_predictions = self.predictions[best_model]
        y_test_values = self.y_test.values if hasattr(self.y_test, 'values') else self.y_test
        
        # Ensure all arrays have the same length
        min_length = min(len(y_test_values), len(best_predictions), len(best_errors))
        y_test_trimmed = y_test_values[:min_length]
        predictions_trimmed = best_predictions[:min_length]
        errors_trimmed = best_errors[:min_length]
        
        # Create error analysis dataframe
        error_df = self.X_test.iloc[:min_length].copy()
        error_df['Actual'] = y_test_trimmed
        error_df['Predicted'] = predictions_trimmed
        error_df['Error'] = errors_trimmed
        error_df['Abs_Error'] = np.abs(errors_trimmed)
        
        # Handle division by zero
        with np.errstate(divide='ignore', invalid='ignore'):
            error_percentage = (errors_trimmed / y_test_trimmed) * 100
            error_percentage = np.where(np.isfinite(error_percentage), error_percentage, 0)
        error_df['Error_Percentage'] = error_percentage
        
        # Identify high error cases
        high_error_threshold = np.percentile(np.abs(errors_trimmed), 90)
        error_df['High_Error'] = error_df['Abs_Error'] > high_error_threshold
        
        print(f"High error threshold (90th percentile): {high_error_threshold:.2f}")
        print(f"Number of high error cases: {error_df['High_Error'].sum()}")
        
        return error_df, best_model
        
    def create_error_visualizations(self, error_df, best_model):
        """
        Create comprehensive error visualizations
        """
        print("\nCreating error visualizations...")
        
        # Set up the plotting style
        plt.style.use('default')
        sns.set_palette("husl")
        
        # Create first figure: 2x2 layout for main analysis
        fig1 = plt.figure(figsize=(16, 12))
        fig1.suptitle('CatBoost Model Error Analysis (Graph 1)', fontsize=20, fontweight='bold', y=0.98)
        
        # 1. Error Distribution
        plt.subplot(2, 2, 1)
        try:
            plt.hist(error_df['Error'], bins=50, alpha=0.7, edgecolor='black', color='skyblue')
            plt.axvline(0, color='red', linestyle='--', alpha=0.8, linewidth=2)
            plt.title('Error Distribution', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Prediction Error', fontsize=12)
            plt.ylabel('Frequency', fontsize=12)
            plt.grid(True, alpha=0.3)
        except Exception as e:
            plt.text(0.5, 0.5, f'Error Distribution\nUnavailable\n{str(e)[:30]}', 
                    ha='center', va='center', transform=plt.gca().transAxes)
            plt.title('Error Distribution', fontsize=16, fontweight='bold', pad=20)
        
        # 2. Actual vs Predicted
        plt.subplot(2, 2, 2)
        try:
            plt.scatter(error_df['Actual'], error_df['Predicted'], alpha=0.6, s=1, color='coral')
            min_val = min(error_df['Actual'].min(), error_df['Predicted'].min())
            max_val = max(error_df['Actual'].max(), error_df['Predicted'].max())
            plt.plot([min_val, max_val], [min_val, max_val], 'r--', alpha=0.8, linewidth=2)
            plt.title('Actual vs Predicted Values', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Actual Values', fontsize=12)
            plt.ylabel('Predicted Values', fontsize=12)
            plt.grid(True, alpha=0.3)
        except Exception as e:
            plt.text(0.5, 0.5, f'Actual vs Predicted\nUnavailable\n{str(e)[:30]}', 
                    ha='center', va='center', transform=plt.gca().transAxes)
            plt.title('Actual vs Predicted Values', fontsize=16, fontweight='bold', pad=20)
        
        # 3. Residual Plot
        plt.subplot(2, 2, 3)
        try:
            plt.scatter(error_df['Predicted'], error_df['Error'], alpha=0.6, s=1, color='lightgreen')
            plt.axhline(0, color='red', linestyle='--', alpha=0.8, linewidth=2)
            plt.title('Residual Plot', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Predicted Values', fontsize=12)
            plt.ylabel('Residuals', fontsize=12)
            plt.grid(True, alpha=0.3)
        except Exception as e:
            plt.text(0.5, 0.5, f'Residual Plot\nUnavailable\n{str(e)[:30]}', 
                    ha='center', va='center', transform=plt.gca().transAxes)
            plt.title('Residual Plot', fontsize=16, fontweight='bold', pad=20)
        
        # 4. Error by Prediction Range
        plt.subplot(2, 2, 4)
        try:
            # Create bins with proper handling
            pred_range = error_df['Predicted'].max() - error_df['Predicted'].min()
            if pred_range > 0:
                error_df_temp = error_df.copy()
                error_df_temp['Pred_Bins'] = pd.cut(error_df_temp['Predicted'], bins=10, duplicates='drop')
                error_by_range = error_df_temp.groupby('Pred_Bins')['Abs_Error'].mean()
                
                # Create bar plot with proper formatting
                ax = error_by_range.plot(kind='bar', color='gold', alpha=0.7)
                plt.title('Average Error by Prediction Range', fontsize=16, fontweight='bold', pad=20)
                plt.xlabel('Prediction Range', fontsize=12)
                plt.ylabel('Average Absolute Error', fontsize=12)
                plt.xticks(rotation=45, ha='right')
                plt.grid(True, alpha=0.3)
            else:
                plt.text(0.5, 0.5, 'Insufficient\nPrediction Range\nVariation', 
                        ha='center', va='center', transform=plt.gca().transAxes)
                plt.title('Error by Prediction Range', fontsize=16, fontweight='bold', pad=20)
        except Exception as e:
            plt.text(0.5, 0.5, f'Error by Range\nUnavailable\n{str(e)[:30]}', 
                    ha='center', va='center', transform=plt.gca().transAxes)
            plt.title('Error by Prediction Range', fontsize=16, fontweight='bold', pad=20)
        
        plt.tight_layout(pad=3.0)
        
        # Save the first visualization
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename1 = f'error_analysis_primary_{timestamp}.png'
        plt.savefig(filename1, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Primary error analysis visualization saved as: {filename1}")
        plt.show()
        
        # Create second figure: Error Analysis Dashboard
        fig2 = plt.figure(figsize=(16, 12))
        fig2.suptitle('CatBoost Model Error Analysis (Graph 2)', fontsize=20, fontweight='bold', y=0.96)
        
        # Create a grid layout: 2 rows, 4 columns
        gs = fig2.add_gridspec(2, 4, height_ratios=[1, 1], width_ratios=[1, 1, 1, 1], 
                              hspace=0.35, wspace=0.3)
        
        # 1. Error Distribution (top left)
        ax1 = fig2.add_subplot(gs[0, 0])
        try:
            ax1.hist(error_df['Error'], bins=30, alpha=0.7, edgecolor='black', color='skyblue')
            ax1.axvline(0, color='red', linestyle='--', alpha=0.8, linewidth=2)
            ax1.set_title('Error Distribution', fontsize=14, fontweight='bold')
            ax1.set_xlabel('Prediction Error', fontsize=10)
            ax1.set_ylabel('Frequency', fontsize=10)
            ax1.grid(True, alpha=0.3)
        except Exception as e:
            ax1.text(0.5, 0.5, f'Error Distribution\nUnavailable', 
                    ha='center', va='center', transform=ax1.transAxes)
            ax1.set_title('Error Distribution', fontsize=14, fontweight='bold')
        
        # 2. Error Percentage Distribution (top center-left)
        ax2 = fig2.add_subplot(gs[0, 1])
        try:
            valid_percentages = error_df['Error_Percentage'][np.isfinite(error_df['Error_Percentage'])]
            # Filter extreme outliers for better visualization
            percentile_95 = np.percentile(np.abs(valid_percentages), 95)
            filtered_percentages = valid_percentages[np.abs(valid_percentages) <= percentile_95]
            
            if len(filtered_percentages) > 0:
                ax2.hist(filtered_percentages, bins=30, alpha=0.7, edgecolor='black', color='plum')
                ax2.axvline(0, color='red', linestyle='--', alpha=0.8, linewidth=2)
                ax2.set_title('Error Percentage Distribution', fontsize=14, fontweight='bold')
                ax2.set_xlabel('Error Percentage (%)', fontsize=10)
                ax2.set_ylabel('Frequency', fontsize=10)
                ax2.grid(True, alpha=0.3)
            else:
                ax2.text(0.5, 0.5, 'No valid\nerror percentages', 
                        ha='center', va='center', transform=ax2.transAxes)
                ax2.set_title('Error Percentage Distribution', fontsize=14, fontweight='bold')
        except Exception as e:
            ax2.text(0.5, 0.5, f'Error Percentage\nUnavailable', 
                    ha='center', va='center', transform=ax2.transAxes)
            ax2.set_title('Error Percentage Distribution', fontsize=14, fontweight='bold')
        
        # 3. Q-Q Plot for Error Normality (top center-right)
        ax3 = fig2.add_subplot(gs[0, 2])
        try:
            from scipy import stats
            # Sample data if too large for performance
            sample_errors = error_df['Error'].sample(min(5000, len(error_df))) if len(error_df) > 5000 else error_df['Error']
            stats.probplot(sample_errors, dist="norm", plot=ax3)
            ax3.set_title('Q-Q Plot (Error Normality)', fontsize=14, fontweight='bold')
            ax3.grid(True, alpha=0.3)
        except ImportError:
            ax3.text(0.5, 0.5, 'scipy not available\nfor Q-Q plot', 
                    ha='center', va='center', transform=ax3.transAxes)
            ax3.set_title('Q-Q Plot (scipy required)', fontsize=14, fontweight='bold')
        except Exception as e:
            ax3.text(0.5, 0.5, f'Q-Q Plot\nUnavailable', 
                    ha='center', va='center', transform=ax3.transAxes)
            ax3.set_title('Q-Q Plot', fontsize=14, fontweight='bold')
        
        # 4. Cumulative Error Distribution (top right)
        ax4 = fig2.add_subplot(gs[0, 3])
        try:
            sorted_abs_errors = np.sort(error_df['Abs_Error'])
            cumulative_pct = np.arange(1, len(sorted_abs_errors) + 1) / len(sorted_abs_errors) * 100
            ax4.plot(sorted_abs_errors, cumulative_pct, color='darkgreen', linewidth=2)
            ax4.set_title('Cumulative Error Distribution', fontsize=14, fontweight='bold')
            ax4.set_xlabel('Absolute Error', fontsize=10)
            ax4.set_ylabel('Cumulative %', fontsize=10)
            ax4.grid(True, alpha=0.3)
            
            # Add percentile markers
            percentiles = [50, 90, 95]
            for p in percentiles:
                value = np.percentile(sorted_abs_errors, p)
                ax4.axvline(value, color='red', linestyle=':', alpha=0.7)
                ax4.text(value, p, f'{p}%', rotation=90, va='bottom', fontsize=8)
                
        except Exception as e:
            ax4.text(0.5, 0.5, f'Cumulative Plot\nUnavailable', 
                    ha='center', va='center', transform=ax4.transAxes)
            ax4.set_title('Cumulative Error Distribution', fontsize=14, fontweight='bold')
        
        # 5. High Error Cases Analysis (bottom left)
        ax5 = fig2.add_subplot(gs[1, 0])
        try:
            if 'High_Error' in error_df.columns and error_df['High_Error'].nunique() > 1:
                # Create manual boxplot
                high_errors = error_df[error_df['High_Error']]['Abs_Error']
                normal_errors = error_df[~error_df['High_Error']]['Abs_Error']
                
                data_to_plot = [normal_errors, high_errors]
                box_plot = ax5.boxplot(data_to_plot, labels=['Normal', 'High Error'], patch_artist=True)
                box_plot['boxes'][0].set_facecolor('lightblue')
                box_plot['boxes'][1].set_facecolor('lightcoral')
                
                ax5.set_title('Error Distribution: High vs Normal', fontsize=14, fontweight='bold')
                ax5.set_ylabel('Absolute Error', fontsize=10)
                ax5.grid(True, alpha=0.3)
            else:
                ax5.text(0.5, 0.5, 'Insufficient\nHigh Error\nVariation', 
                        ha='center', va='center', transform=ax5.transAxes)
                ax5.set_title('High Error Analysis', fontsize=14, fontweight='bold')
        except Exception as e:
            ax5.text(0.5, 0.5, f'High Error Analysis\nUnavailable', 
                    ha='center', va='center', transform=ax5.transAxes)
            ax5.set_title('High Error Analysis', fontsize=14, fontweight='bold')
        
        # 6. Error Statistics Summary (bottom center-left)
        ax6 = fig2.add_subplot(gs[1, 1])
        try:
            ax6.axis('off')
            # Create error statistics text
            error_stats = f"""Error Statistics:
            
Mean Error: {error_df['Error'].mean():.2f}
Std Error: {error_df['Error'].std():.2f}
Median Error: {error_df['Error'].median():.2f}

Mean Abs Error: {error_df['Abs_Error'].mean():.2f}
95th Percentile: {np.percentile(error_df['Abs_Error'], 95):.2f}

High Error Cases: {error_df['High_Error'].sum() if 'High_Error' in error_df.columns else 'N/A'}"""
            
            ax6.text(0.1, 0.9, error_stats, transform=ax6.transAxes, fontsize=11, 
                    verticalalignment='top', fontfamily='monospace',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='lightgray', alpha=0.8))
            ax6.set_title('Error Statistics', fontsize=14, fontweight='bold')
        except Exception as e:
            ax6.text(0.5, 0.5, f'Error Statistics\nUnavailable', 
                    ha='center', va='center', transform=ax6.transAxes)
            ax6.set_title('Error Statistics', fontsize=14, fontweight='bold')
        
        # 7. Error Magnitude Distribution (bottom center-right)
        ax7 = fig2.add_subplot(gs[1, 2])
        try:
            ax7.hist(error_df['Abs_Error'], bins=30, alpha=0.7, edgecolor='black', color='orange')
            ax7.set_title('Error Magnitude Distribution', fontsize=14, fontweight='bold')
            ax7.set_xlabel('Absolute Error', fontsize=10)
            ax7.set_ylabel('Frequency', fontsize=10)
            ax7.grid(True, alpha=0.3)
        except Exception as e:
            ax7.text(0.5, 0.5, f'Error Magnitude\nUnavailable', 
                    ha='center', va='center', transform=ax7.transAxes)
            ax7.set_title('Error Magnitude Distribution', fontsize=14, fontweight='bold')
        
        # 8. Residual vs Fitted Plot (bottom right)
        ax8 = fig2.add_subplot(gs[1, 3])
        try:
            ax8.scatter(error_df['Predicted'], error_df['Error'], alpha=0.5, s=1, color='purple')
            ax8.axhline(0, color='red', linestyle='--', alpha=0.8, linewidth=2)
            ax8.set_title('Residual vs Fitted', fontsize=14, fontweight='bold')
            ax8.set_xlabel('Fitted Values', fontsize=10)
            ax8.set_ylabel('Residuals', fontsize=10)
            ax8.grid(True, alpha=0.3)
        except Exception as e:
            ax8.text(0.5, 0.5, f'Residual Plot\nUnavailable', 
                    ha='center', va='center', transform=ax8.transAxes)
            ax8.set_title('Residual vs Fitted', fontsize=14, fontweight='bold')
        
        plt.tight_layout(pad=3.0)
        
        # Save the second visualization
        filename2 = f'error_analysis_dashboard_{timestamp}.png'
        plt.savefig(filename2, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Error analysis dashboard saved as: {filename2}")
        plt.show()
        
        return [filename1, filename2]
        
    def save_error_report(self, error_df, best_model):
        """
        Save comprehensive error analysis report
        """
        print("\nSaving error analysis report...")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save detailed metrics
        metrics_filename = f'error_metrics_{timestamp}.csv'
        self.metrics_df.to_csv(metrics_filename, index=False)
        
        # Save high error cases
        high_error_cases = error_df[error_df['High_Error']].copy()
        high_error_filename = f'high_error_cases_{timestamp}.csv'
        high_error_cases.to_csv(high_error_filename, index=False)
        
        # Create summary report
        report = {
            'analysis_timestamp': timestamp,
            'model': best_model,
            'model_description': 'Finalized CatBoost model for restaurant demand prediction',
            'dataset_info': {
                'total_samples': len(self.data),
                'test_samples': len(error_df),
                'features': list(self.X_test.columns)
            },
            'error_summary': {
                'mean_absolute_error': float(error_df['Abs_Error'].mean()),
                'median_absolute_error': float(error_df['Abs_Error'].median()),
                'max_absolute_error': float(error_df['Abs_Error'].max()),
                'error_std': float(error_df['Error'].std()),
                'high_error_cases': int(error_df['High_Error'].sum()),
                'high_error_percentage': float(error_df['High_Error'].mean() * 100)
            },
            'model_performance': self.metrics_df[['Model', 'R²', 'RMSE', 'MAE']].to_dict('records')[0] if not self.metrics_df.empty else {}
        }
        
        report_filename = f'error_analysis_report_{timestamp}.json'
        with open(report_filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"Error analysis complete!")
        print(f"Files saved:")
        print(f"  - Metrics: {metrics_filename}")
        print(f"  - High error cases: {high_error_filename}")
        print(f"  - Summary report: {report_filename}")
        
        return report_filename
        
    def run_complete_analysis(self):
        """
        Run the complete error analysis pipeline
        """
        print("Starting comprehensive error analysis...")
        print("=" * 50)
        
        # Load data and models
        self.load_data()
        self.load_models()
        
        if not self.models:
            print("No models found! Please ensure trained models are available.")
            return None
            
        # Generate predictions and analyze errors
        self.generate_predictions()
        self.calculate_error_metrics()
        error_df, best_model = self.analyze_error_patterns()
        
        if error_df is None or best_model is None:
            print("\nError analysis failed - no successful model predictions found.")
            print("Please check that:")
            print("1. Model files are valid and contain trained models")
            print("2. Feature engineering is working correctly")
            print("3. Data preprocessing is compatible with model expectations")
            return None
        
        # Create visualizations
        viz_filename = self.create_error_visualizations(error_df, best_model)
        
        # Save comprehensive report
        report_filename = self.save_error_report(error_df, best_model)
        
        print("\n" + "=" * 50)
        print("CatBoost error analysis completed successfully!")
        print(f"Model analyzed: {best_model}")
        print(f"Visualization: {viz_filename}")
        print(f"Report: {report_filename}")
        
        return {
            'best_model': best_model,
            'metrics': self.metrics_df,
            'error_data': error_df,
            'visualization': viz_filename,
            'report': report_filename
        }

def main():
    """
    Main function to run error analysis
    """
    analyzer = FinalErrorAnalyzer()
    results = analyzer.run_complete_analysis()
    return results

if __name__ == "__main__":
    main()