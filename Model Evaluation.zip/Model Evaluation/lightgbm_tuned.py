#!/usr/bin/env python3
"""
Fine-Tuned LightGBM Model for Restaurant Demand Forecasting

This script implements a LightGBM model with hyperparameter optimization
using cross-validation and a focused search space.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, make_scorer
import lightgbm as lgb
import warnings
import time
import joblib
from unified_restaurant_demand_system import RestaurantFeatureEngineer

warnings.filterwarnings('ignore')

class TunedLightGBMPipeline:
    """
    Fine-tuned LightGBM pipeline for restaurant demand forecasting.
    Implements hyperparameter optimization with cross-validation.
    """
    
    def __init__(self, data_path, random_state=42):
        """
        Initialize the tuned LightGBM pipeline.
        
        Args:
            data_path (str): Path to the dataset
            random_state (int): Random seed for reproducibility
        """
        self.data_path = data_path
        self.random_state = random_state
        self.feature_engineer = RestaurantFeatureEngineer(data_path)
        self.best_model = None
        self.best_params = None
        self.cv_results = None
        self.results = {}
        
        # Set random seeds for reproducibility
        np.random.seed(random_state)
        
    def prepare_data(self):
        """
        Prepare the dataset with feature engineering.
        
        Returns:
            tuple: X_train, X_test, y_train, y_test
        """
        print("=== DATA PREPARATION ===")
        
        # Load and engineer features
        df = self.feature_engineer.engineer_features_for_existing_items()
        
        # Select features for modeling
        feature_columns = [
            # Historical demand features
            'lag_1_day', 'lag_7_day', 'ma_7_day', 'ma_30_day', 'std_7_day', 'trend_7_day',
            
            # Price features
            'price_gap', 'profit_margin', 'price_to_cost_ratio', 'market_price_ratio', 'price_rank_in_category',
            
            # Categorical features (encoded)
            'category_encoded', 'cuisine_type_encoded', 'meal_type_encoded', 'restaurant_type_encoded',
            'ingredient_count',
            
            # Contextual features
            'day_of_week_num', 'day_sin', 'day_cos', 'month', 'month_sin', 'month_cos',
            'is_weekend', 'weekend_lunch', 'weekend_dinner',
            
            # Restaurant features
            'restaurant_demand_mean', 'restaurant_demand_std',
            
            # Interaction features
            'price_special_event', 'price_promotion', 'price_weekend',
            'category_restaurant_interaction', 'meal_day_interaction'
        ]
        
        # Filter features that exist in the dataset
        available_features = [col for col in feature_columns if col in df.columns]
        print(f"Using {len(available_features)} features for modeling")
        
        # Prepare features and target
        X = df[available_features].fillna(0)
        y = df['demand']
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=None
        )
        
        print(f"Training set: {X_train.shape[0]} samples")
        print(f"Test set: {X_test.shape[0]} samples")
        print(f"Features: {X_train.shape[1]}")
        
        return X_train, X_test, y_train, y_test
    
    def calculate_mape(self, y_true, y_pred):
        """
        Calculate Mean Absolute Percentage Error.
        
        Args:
            y_true: True values
            y_pred: Predicted values
            
        Returns:
            float: MAPE value
        """
        return np.mean(np.abs((y_true - y_pred) / np.maximum(y_true, 1e-8))) * 100
    
    def tune_hyperparameters(self, X_train, y_train):
        print("\n=== HYPERPARAMETER TUNING ===")
        
        param_grid = {
            'n_estimators': [250,260],        
            'max_depth': [10,11],             
            'learning_rate': [0.04, 0.05],     
            'num_leaves': [66,67],            
            'subsample': [0.7, 0.8],           
            'colsample_bytree': [0.9,1.0]    
        }
        
        print(f"Parameter grid: {param_grid}")
        print(f"Total combinations: {np.prod([len(v) for v in param_grid.values()])}")
        
        # Initialize LightGBM
        lgb_model = lgb.LGBMRegressor(
            random_state=self.random_state,
            n_jobs=-1,
            verbosity=-1,
            objective='regression'
        )
        
        # Custom scorer for negative RMSE (since GridSearchCV maximizes)
        rmse_scorer = make_scorer(
            lambda y_true, y_pred: -np.sqrt(mean_squared_error(y_true, y_pred)),
            greater_is_better=True
        )
        
        # Grid search with cross-validation
        grid_search = GridSearchCV(
            estimator=lgb_model,
            param_grid=param_grid,
            cv=3,  # 3-fold cross-validation
            scoring=rmse_scorer,
            n_jobs=-1,
            verbose=1,
            return_train_score=True
        )

        print("\nStarting grid search with 3-fold cross-validation...")
        start_time = time.time()
        
        grid_search.fit(X_train, y_train)
        
        tuning_time = time.time() - start_time
        print(f"Hyperparameter tuning completed in {tuning_time:.2f} seconds")
        
        # Store results
        self.best_model = grid_search.best_estimator_
        self.best_params = grid_search.best_params_
        self.cv_results = grid_search.cv_results_
        
        print(f"\nBest parameters: {self.best_params}")
        print(f"Best cross-validation RMSE: {-grid_search.best_score_:.4f}")
        
        return grid_search
    
    def evaluate_model(self, X_train, X_test, y_train, y_test):
        """
        Evaluate the best model on training and test sets.
        
        Args:
            X_train, X_test: Training and test features
            y_train, y_test: Training and test targets
        """
        print("\n=== MODEL EVALUATION ===")
        
        # Predictions
        y_train_pred = self.best_model.predict(X_train)
        y_test_pred = self.best_model.predict(X_test)
        
        # Calculate metrics
        train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
        test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
        
        train_mae = mean_absolute_error(y_train, y_train_pred)
        test_mae = mean_absolute_error(y_test, y_test_pred)
        
        train_r2 = r2_score(y_train, y_train_pred)
        test_r2 = r2_score(y_test, y_test_pred)
        
        train_mape = self.calculate_mape(y_train, y_train_pred)
        test_mape = self.calculate_mape(y_test, y_test_pred)
        
        # Cross-validation scores on full training set
        cv_scores = cross_val_score(
            self.best_model, X_train, y_train, 
            cv=3, scoring='r2', n_jobs=-1
        )
        
        # Store results
        self.results = {
            'best_params': self.best_params,
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_mae': train_mae,
            'test_mae': test_mae,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_mape': train_mape,
            'test_mape': test_mape,
            'cv_r2_mean': cv_scores.mean(),
            'cv_r2_std': cv_scores.std(),
            'overfitting': train_r2 - test_r2
        }
        
        # Print results
        print(f"\nFinal Model Performance:")
        print(f"  Best Parameters: {self.best_params}")
        print(f"  Train R²: {train_r2:.4f} | Test R²: {test_r2:.4f}")
        print(f"  Train RMSE: {train_rmse:.4f} | Test RMSE: {test_rmse:.4f}")
        print(f"  Train MAE: {train_mae:.4f} | Test MAE: {test_mae:.4f}")
        print(f"  Train MAPE: {train_mape:.2f}% | Test MAPE: {test_mape:.2f}%")
        print(f"  Cross-validation R²: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
        print(f"  Overfitting (R² diff): {train_r2 - test_r2:.4f}")
        
        # Feature importance analysis
        self.analyze_feature_importance(X_train)
    
    def analyze_feature_importance(self, X_train):
        """
        Analyze and display feature importance.
        
        Args:
            X_train: Training features
        """
        print("\n=== FEATURE IMPORTANCE ANALYSIS ===")
        
        # Get feature importance
        feature_importance = pd.DataFrame({
            'feature': X_train.columns,
            'importance': self.best_model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print("\nTop 10 Most Important Features:")
        print("-" * 40)
        for i, (_, row) in enumerate(feature_importance.head(10).iterrows(), 1):
            print(f"{i:2d}. {row['feature']:<25}: {row['importance']:.4f}")
        
        # Store feature importance
        self.results['feature_importance'] = feature_importance.to_dict('records')
    
    def save_model(self, filepath=None):
        """
        Save the trained model to disk.
        
        Args:
            filepath (str): Path to save the model
        """
        if filepath is None:
            filepath = f"lightgbm_tuned_model_{int(time.time())}.joblib"
        
        joblib.dump({
            'model': self.best_model,
            'params': self.best_params,
            'results': self.results,
            'feature_engineer': self.feature_engineer
        }, filepath)
        
        print(f"\nModel saved to: {filepath}")
        return filepath
    
    def run_tuned_pipeline(self):
        """
        Run the complete tuned LightGBM pipeline.
        
        Returns:
            dict: Results dictionary
        """
        print("FINE-TUNED LIGHTGBM PIPELINE FOR RESTAURANT DEMAND FORECASTING")
        print("=" * 80)
        
        # Prepare data
        X_train, X_test, y_train, y_test = self.prepare_data()
        
        # Tune hyperparameters
        grid_search = self.tune_hyperparameters(X_train, y_train)
        
        # Evaluate best model
        self.evaluate_model(X_train, X_test, y_train, y_test)
        
        # Save model
        model_path = self.save_model()
        
        print("\n" + "="*80)
        print("LIGHTGBM TUNING COMPLETED SUCCESSFULLY!")
        print("="*80)
        print(f"Best Test R²: {self.results['test_r2']:.4f}")
        print(f"Best Test RMSE: {self.results['test_rmse']:.4f}")
        print(f"Model saved to: {model_path}")
        
        return self.results

def main():
    """
    Main function to run the tuned LightGBM pipeline.
    """
    # Initialize pipeline
    data_path = "cleaned_streamlined_ultimate_malaysian_data.csv"
    pipeline = TunedLightGBMPipeline(data_path, random_state=42)
    
    # Run pipeline
    results = pipeline.run_tuned_pipeline()
    
    print("\nTuned LightGBM pipeline completed successfully!")
    print(f"Final Test R² Score: {results['test_r2']:.4f}")

if __name__ == "__main__":
    main()