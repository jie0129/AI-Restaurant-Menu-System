import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class BusinessLogicValidator:
    def __init__(self, data_path):
        self.data = pd.read_csv(data_path)
        self.validation_results = {}
        self.business_insights = []
        self.explanations = {}
        
    def validate_restaurant_type_impact(self):
        """Validate restaurant type vs quantity sold relationship.
        Expected: Fast Food > Casual Dining > Fine Dining (volume-based expectation)"""
        print("\n=== RESTAURANT TYPE vs QUANTITY SOLD VALIDATION ===")
        
        type_stats = self.data.groupby('restaurant_type')['quantity_sold'].agg([
            'mean', 'median', 'count'
        ]).round(2)
        
        print("\nQuantity sold by restaurant type:")
        print(type_stats)
        
        # Business logic: Fast food typically has higher volume than fine dining
        fast_food_avg = type_stats.loc['Fast Food', 'mean'] if 'Fast Food' in type_stats.index else 0
        fine_dining_avg = type_stats.loc['Fine Dining', 'mean'] if 'Fine Dining' in type_stats.index else 0
        
        logic_check = fast_food_avg > fine_dining_avg
        
        print(f"\nBusiness Logic Check: Fast Food ({fast_food_avg:.1f}) > Fine Dining ({fine_dining_avg:.1f}): {logic_check}")
        
        explanation = {
            'check': 'Restaurant Type Impact',
            'expected': 'Fast Food should have higher average quantity than Fine Dining due to volume-based business models',
            'result': logic_check,
            'justification': 'Fast food targets high volume, fine dining targets premium quality.'
        }
        
        if logic_check:
            self.business_insights.append("✓ Restaurant type follows expected volume pattern")
            explanation['status'] = 'PASS - Data aligns with expected business model differences'
        else:
            self.business_insights.append("⚠ Restaurant type volume pattern unexpected")
            explanation['status'] = 'FAIL - Fine dining should have lower volumes than street food'
            
        self.explanations['restaurant_type'] = explanation
        self.validation_results['restaurant_type'] = {
            'logic_valid': logic_check,
            'fast_food_avg': fast_food_avg,
            'fine_dining_avg': fine_dining_avg
        }
        
    def validate_price_demand_curve(self):
        """
        Validate price vs quantity relationship.
        Expected: Negative correlation (higher price = lower quantity)
        """
        print("\n=== PRICE vs QUANTITY DEMAND CURVE VALIDATION ===")
        
        correlation = self.data['actual_selling_price'].corr(self.data['quantity_sold'])
        
        print(f"\nPrice-Quantity Correlation: {correlation:.3f}")
        
        logic_check = correlation < 0
        
        print(f"Business Logic Check: Negative correlation (demand curve): {logic_check}")
        
        explanation = {
            'check': 'Price-Demand Curve',
            'expected': 'Negative correlation between price and quantity (basic economic principle)',
            'result': logic_check,
            'correlation': correlation,
            'justification': 'Basic economic principle: higher prices reduce demand.'
        }
        
        if logic_check:
            self.business_insights.append("✓ Price follows expected demand curve (higher price = lower quantity)")
            explanation['status'] = 'PASS - Data follows fundamental economic principles'
        else:
            self.business_insights.append("⚠ Price-demand relationship unexpected")
            explanation['status'] = 'FAIL - Price should decrease demand per economic principles.'
            
        self.explanations['price_demand'] = explanation
        self.validation_results['price_demand'] = {
            'logic_valid': logic_check,
            'correlation': correlation
        }
        
    def validate_promotion_impact(self):
        """
        Validate promotion vs quantity sold relationship.
        Expected: Promotions should increase sales
        """
        print("\n=== PROMOTION IMPACT VALIDATION ===")
        
        # Convert has_promotion to boolean
        self.data['promotion_active'] = self.data['has_promotion'].astype(bool)
        
        promo_stats = self.data.groupby('promotion_active')['quantity_sold'].agg([
            'mean', 'median', 'count'
        ]).round(2)
        
        print("\nQuantity sold by promotion status:")
        print(promo_stats)
        
        promo_avg = promo_stats.loc[True, 'mean'] if True in promo_stats.index else 0
        no_promo_avg = promo_stats.loc[False, 'mean'] if False in promo_stats.index else 0
        
        logic_check = promo_avg > no_promo_avg
        increase_pct = ((promo_avg - no_promo_avg) / no_promo_avg * 100) if no_promo_avg > 0 else 0
        
        print(f"\nBusiness Logic Check: Promotion ({promo_avg:.1f}) > No Promotion ({no_promo_avg:.1f}): {logic_check}")
        print(f"Sales increase with promotions: {increase_pct:.1f}%")
        
        explanation = {
            'check': 'Promotion Impact',
            'expected': 'Active promotions should drive higher sales volumes',
            'result': logic_check,
            'increase_percentage': increase_pct,
            'justification': 'Promotions reduce price or add value, increasing demand.'
        }
        
        if logic_check:
            self.business_insights.append(f"✓ Promotions increase sales by {increase_pct:.1f}%")
            explanation['status'] = 'PASS - Promotions effectively drive sales as expected'
        else:
            self.business_insights.append("⚠ Promotion impact unexpected")
            explanation['status'] = 'FAIL - Promotions should increase sales volumes'
            
        self.explanations['promotion'] = explanation
        self.validation_results['promotion'] = {
            'logic_valid': logic_check,
            'promo_avg': promo_avg,
            'no_promo_avg': no_promo_avg,
            'increase_pct': increase_pct
        }
        
    def validate_weekend_effect(self):
        """
        Validate weekend vs weekday sales pattern.
        Expected: Weekend sales should be higher for restaurants
        """
        print("\n=== WEEKEND EFFECT VALIDATION ===")
        
        # Convert date to datetime if it's not already
        if 'date' in self.data.columns:
            self.data['date'] = pd.to_datetime(self.data['date'])
            self.data['is_weekend'] = self.data['date'].dt.dayofweek >= 5
        elif 'is_weekend' not in self.data.columns:
            # If no date column, create a mock weekend column for demonstration
            self.data['is_weekend'] = np.random.choice([True, False], size=len(self.data), p=[0.3, 0.7])
        
        weekend_stats = self.data.groupby('is_weekend')['quantity_sold'].agg([
            'mean', 'median', 'count'
        ]).round(2)
        
        print("\nQuantity sold by weekend status:")
        print(weekend_stats)
        
        weekend_avg = weekend_stats.loc[True, 'mean'] if True in weekend_stats.index else 0
        weekday_avg = weekend_stats.loc[False, 'mean'] if False in weekend_stats.index else 0
        
        logic_check = weekend_avg > weekday_avg
        increase_pct = ((weekend_avg - weekday_avg) / weekday_avg * 100) if weekday_avg > 0 else 0
        
        print(f"\nBusiness Logic Check: Weekend ({weekend_avg:.1f}) > Weekday ({weekday_avg:.1f}): {logic_check}")
        print(f"Weekend sales increase: {increase_pct:.1f}%")
        
        explanation = {
            'check': 'Weekend Effect',
            'expected': 'Weekend sales should be higher due to increased leisure dining',
            'result': logic_check,
            'increase_percentage': increase_pct,
            'justification': 'Weekends have more leisure time and dining occasions.'
        }
        
        if logic_check:
            self.business_insights.append(f"✓ Weekend sales higher by {increase_pct:.1f}%")
            explanation['status'] = 'PASS - Weekend effect aligns with typical dining patterns'
        else:
            self.business_insights.append("⚠ Weekend effect unexpected")
            explanation['status'] = 'FAIL - Weekend sales should be higher than weekday sales'
            
        self.explanations['weekend'] = explanation
        self.validation_results['weekend'] = {
            'logic_valid': logic_check,
            'weekend_avg': weekend_avg,
            'weekday_avg': weekday_avg,
            'increase_pct': increase_pct
        }
        
    def validate_meal_type_patterns(self):
        """
        Validate meal type quantity patterns.
        Expected: Lunch/Dinner > Breakfast (typical dining patterns)
        """
        print("\n=== MEAL TYPE PATTERNS VALIDATION ===")
        
        meal_stats = self.data.groupby('meal_type')['quantity_sold'].agg([
            'mean', 'median', 'count'
        ]).round(2)
        
        print("\nQuantity sold by meal type:")
        print(meal_stats)
        
        breakfast_avg = meal_stats.loc['Breakfast', 'mean'] if 'Breakfast' in meal_stats.index else 0
        lunch_avg = meal_stats.loc['Lunch', 'mean'] if 'Lunch' in meal_stats.index else 0
        dinner_avg = meal_stats.loc['Dinner', 'mean'] if 'Dinner' in meal_stats.index else 0
        
        logic_check = (lunch_avg > breakfast_avg) and (dinner_avg > breakfast_avg)
        
        print(f"\nBusiness Logic Check: Lunch ({lunch_avg:.1f}) & Dinner ({dinner_avg:.1f}) > Breakfast ({breakfast_avg:.1f}): {logic_check}")
        
        explanation = {
            'check': 'Meal Type Patterns',
            'expected': 'Lunch and Dinner should have higher volumes than Breakfast',
            'result': logic_check,
            'breakfast_avg': breakfast_avg,
            'lunch_avg': lunch_avg,
            'dinner_avg': dinner_avg,
            'justification': 'Lunch and dinner are larger, more social meals than breakfast.'
        }
        
        if logic_check:
            self.business_insights.append("✓ Meal types follow expected pattern (Lunch/Dinner > Breakfast)")
            explanation['status'] = 'PASS - Meal patterns align with typical dining behaviors'
        else:
            self.business_insights.append("⚠ Meal type pattern unexpected")
            explanation['status'] = 'FAIL - Lunch and dinner should have higher volumes than breakfast'
            
        self.explanations['meal_type'] = explanation
        self.validation_results['meal_type'] = {
            'logic_valid': logic_check,
            'breakfast_avg': breakfast_avg,
            'lunch_avg': lunch_avg,
            'dinner_avg': dinner_avg
        }
        
    def validate_special_events_impact(self):
        """
        Validate special events vs quantity sold relationship.
        Expected: Special events should increase sales
        """
        print("\n=== SPECIAL EVENTS IMPACT VALIDATION ===")
        
        # Convert special_event to boolean
        self.data['special_event_bool'] = self.data['special_event'].astype(bool)
        
        event_stats = self.data.groupby('special_event_bool')['quantity_sold'].agg([
            'mean', 'median', 'count'
        ]).round(2)
        
        print("\nQuantity sold by special event status:")
        print(event_stats)
        
        event_avg = event_stats.loc[True, 'mean'] if True in event_stats.index else 0
        no_event_avg = event_stats.loc[False, 'mean'] if False in event_stats.index else 0
        
        logic_check = event_avg > no_event_avg
        increase_pct = ((event_avg - no_event_avg) / no_event_avg * 100) if no_event_avg > 0 else 0
        
        print(f"\nBusiness Logic Check: Special Event ({event_avg:.1f}) > No Event ({no_event_avg:.1f}): {logic_check}")
        print(f"Special event sales increase: {increase_pct:.1f}%")
        
        explanation = {
            'check': 'Special Events Impact',
            'expected': 'Special events should drive higher sales volumes',
            'result': logic_check,
            'increase_percentage': increase_pct,
            'justification': 'Special events increase dining out frequency and group occasions.'
        }
        
        if logic_check:
            self.business_insights.append(f"✓ Special events increase sales by {increase_pct:.1f}%")
            explanation['status'] = 'PASS - Special events effectively drive additional sales'
        else:
            self.business_insights.append("⚠ Special events impact unexpected")
            explanation['status'] = 'FAIL - Special events should increase sales volumes'
            
        self.explanations['special_events'] = explanation
        self.validation_results['special_events'] = {
            'logic_valid': logic_check,
            'event_avg': event_avg,
            'no_event_avg': no_event_avg,
            'increase_pct': increase_pct
        }
        
    def validate_cuisine_preferences(self):
        """
        Validate cuisine type preferences.
        Expected: Local cuisines should be prominent in Malaysian market
        """
        print("\n=== CUISINE TYPE PREFERENCES VALIDATION ===")
        
        cuisine_stats = self.data.groupby('cuisine_type')['quantity_sold'].agg([
            'mean', 'sum', 'count'
        ]).round(2)
        
        # Sort by total quantity to see top performers
        cuisine_stats = cuisine_stats.sort_values('sum', ascending=False)
        
        print("\nTop 10 cuisines by total quantity sold:")
        print(cuisine_stats.head(10))
        
        # Check if local cuisines are in top performers
        local_cuisines = ['Malaysian', 'Chinese', 'Malay', 'Indian']
        top_5_cuisines = cuisine_stats.head(5).index.tolist()
        local_in_top5 = sum(1 for cuisine in local_cuisines if cuisine in top_5_cuisines)
        
        logic_check = local_in_top5 >= 2  # At least 2 local cuisines in top 5
        
        print(f"\nTop 5 cuisines: {top_5_cuisines}")
        print(f"Local cuisines in top 5: {local_in_top5}/4")
        print(f"Business Logic Check: Local cuisines dominate: {logic_check}")
        
        explanation = {
            'check': 'Cuisine Preferences',
            'expected': 'Local Malaysian cuisines should be prominent in the market',
            'result': logic_check,
            'local_in_top5': local_in_top5,
            'top_cuisines': top_5_cuisines,
            'justification': 'Local cuisines dominate due to cultural preferences and familiarity.'
        }
        
        if logic_check:
            self.business_insights.append("✓ Local cuisines dominate sales as expected")
            explanation['status'] = 'PASS - Local cuisine preferences align with cultural expectations'
        else:
            self.business_insights.append("⚠ Cuisine preferences unexpected")
            explanation['status'] = 'FAIL - Local cuisines should dominate sales volumes'
            
        self.explanations['cuisine'] = explanation
        self.validation_results['cuisine'] = {
            'logic_valid': logic_check,
            'local_in_top5': local_in_top5,
            'top_cuisines': top_5_cuisines
        }
        
    def validate_profit_margin_relationship(self):
        """
        Validate profit margin vs quantity relationship.
        Expected: Higher profit margins might correlate with lower quantities (premium positioning)
        """
        print("\n=== PROFIT MARGIN vs QUANTITY VALIDATION ===")
        
        # Calculate profit margin using typical_ingredient_cost
        self.data['profit_margin'] = ((self.data['actual_selling_price'] - self.data['typical_ingredient_cost']) / 
                                    self.data['actual_selling_price'] * 100)
        
        correlation = self.data['profit_margin'].corr(self.data['quantity_sold'])
        
        print(f"\nProfit Margin-Quantity Correlation: {correlation:.3f}")
        
        # For profit margin, we might expect negative correlation (higher margin = lower volume)
        logic_check = correlation < 0
        
        print(f"Business Logic Check: Negative correlation (premium positioning): {logic_check}")
        
        explanation = {
            'check': 'Profit Margin Relationship',
            'expected': 'Negative correlation between profit margin and quantity (premium positioning)',
            'result': logic_check,
            'correlation': correlation,
            'justification': 'Higher margins indicate premium positioning with lower volumes.'
        }
        
        if logic_check:
            self.business_insights.append("✓ Profit margin shows negative relationship with quantity")
            explanation['status'] = 'PASS - Data supports premium positioning strategy'
        else:
            self.business_insights.append("⚠ Profit margin relationship unexpected")
            explanation['status'] = 'FAIL - Higher margins should correlate with lower volumes.'
            
        self.explanations['profit_margin'] = explanation
        self.validation_results['profit_margin'] = {
            'logic_valid': logic_check,
            'correlation': correlation
        }
        
    def validate_food_category_volumes(self):
        """
        Validate food category volume patterns.
        Expected: Staple food categories should show high volumes
        """
        print("\n=== FOOD CATEGORY VOLUME PATTERNS VALIDATION ===")
        
        # Use 'category' column from the dataset
        category_stats = self.data.groupby('category')['quantity_sold'].agg([
            'mean', 'sum', 'count'
        ]).round(2)
        
        category_stats = category_stats.sort_values('sum', ascending=False)
        
        print("\nFood categories by total quantity sold:")
        print(category_stats)
        
        # Check if staple foods are prominent
        staple_foods = ['Rice & Noodles', 'Noodles & Rice', 'Rice', 'Noodles', 'Bread', 'Drinks']
        top_3_categories = category_stats.head(3).index.tolist()
        staples_in_top3 = sum(1 for category in staple_foods if category in top_3_categories)
        
        logic_check = staples_in_top3 >= 1  # At least 1 staple food in top 3
        
        print(f"\nTop 3 categories: {top_3_categories}")
        print(f"Staple foods in top 3: {staples_in_top3}")
        print(f"Business Logic Check: Staple foods dominate: {logic_check}")
        
        explanation = {
            'check': 'Food Category Volumes',
            'expected': 'Staple food categories should show high volumes',
            'result': logic_check,
            'staples_in_top3': staples_in_top3,
            'top_categories': top_3_categories,
            'justification': 'Staple foods have higher volumes as meal foundations.'
        }
        
        if logic_check:
            self.business_insights.append("✓ Staple food categories show high volumes as expected")
            explanation['status'] = 'PASS - Food category patterns align with consumption habits'
        else:
            self.business_insights.append("⚠ Food category patterns unexpected")
            explanation['status'] = 'FAIL - Staple food categories should show high volumes'
            
        self.explanations['food_category'] = explanation
        self.validation_results['food_category'] = {
            'logic_valid': logic_check,
            'staples_in_top3': staples_in_top3,
            'top_categories': top_3_categories
        }
        
    def generate_comprehensive_report(self):
        """
        Generate a comprehensive business logic validation report with explanations.
        """
        print("\n" + "="*70)
        print("="*70)
        print("COMPREHENSIVE BUSINESS LOGIC VALIDATION REPORT")
        print("="*70)
        print("="*70)
        
        # Count passed validations
        passed_checks = sum(1 for result in self.validation_results.values() if result['logic_valid'])
        total_checks = len(self.validation_results)
        score = (passed_checks / total_checks) * 100
        
        print(f"\n📊 VALIDATION SUMMARY:")
        print(f"Total Business Logic Checks: {total_checks}")
        print(f"Passed Checks: {passed_checks}")
        print(f"Validation Score: {score:.1f}%")
        
        print(f"\n📋 DETAILED EXPLANATIONS:")
        print("-" * 70)
        
        for i, (key, explanation) in enumerate(self.explanations.items(), 1):
            print(f"\n{i}. {explanation['check'].upper()}")
            print(f"   Expected: {explanation['expected']}")
            print(f"   Result: {'✓ PASS' if explanation['result'] else '⚠ FAIL'}")
            print(f"   Status: {explanation['status']}")
            print(f"   Business Justification: {explanation['justification']}")
            
            # Add specific metrics if available
            if 'correlation' in explanation:
                print(f"   Correlation: {explanation['correlation']:.3f}")
            if 'increase_percentage' in explanation:
                print(f"   Impact: {explanation['increase_percentage']:.1f}% increase")
        
        print(f"\n" + "="*70)
        print("BUSINESS INSIGHTS SUMMARY")
        print("="*70)
        for insight in self.business_insights:
            print(insight)
            
        print(f"\n" + "="*70)
        print(f"OVERALL ASSESSMENT")
        print("="*70)
        
        if score >= 80:
            assessment = "✅ EXCELLENT: Data shows strong business logic consistency"
        elif score >= 60:
            assessment = "✅ GOOD: Data shows reasonable business logic with some variations"
        elif score >= 40:
            assessment = "⚠ FAIR: Data shows mixed business logic patterns"
        else:
            assessment = "❌ POOR: Data shows significant business logic inconsistencies"
            
        print(assessment)
        print(f"\nValidation complete! Score: {score:.1f}%")
        
        return {
            'score': score,
            'passed_checks': passed_checks,
            'total_checks': total_checks,
            'assessment': assessment,
            'explanations': self.explanations
        }
        
    def create_visualizations(self):
        """
        Create visualizations for business logic validation.
        """
        fig, axes = plt.subplots(3, 3, figsize=(20, 15))
        fig.suptitle('Business Logic Validation Analysis', fontsize=16, fontweight='bold')
        
        # 1. Restaurant Type vs Quantity
        if 'restaurant_type' in self.data.columns:
            self.data.groupby('restaurant_type')['quantity_sold'].mean().plot(kind='bar', ax=axes[0,0])
            axes[0,0].set_title('Restaurant Type vs Avg Quantity')
            axes[0,0].tick_params(axis='x', rotation=45)
        
        # 2. Price vs Quantity Scatter
        axes[0,1].scatter(self.data['actual_selling_price'], self.data['quantity_sold'], alpha=0.5)
        axes[0,1].set_title('Price vs Quantity Relationship')
        axes[0,1].set_xlabel('Price')
        axes[0,1].set_ylabel('Quantity Sold')
        
        # 3. Promotion Impact
        if 'promotion_active' in self.data.columns:
            self.data.groupby('promotion_active')['quantity_sold'].mean().plot(kind='bar', ax=axes[0,2])
            axes[0,2].set_title('Promotion Impact on Sales')
        
        # 4. Weekend Effect
        if 'is_weekend' in self.data.columns:
            self.data.groupby('is_weekend')['quantity_sold'].mean().plot(kind='bar', ax=axes[1,0])
            axes[1,0].set_title('Weekend vs Weekday Sales')
        
        # 5. Meal Type Patterns
        if 'meal_type' in self.data.columns:
            self.data.groupby('meal_type')['quantity_sold'].mean().plot(kind='bar', ax=axes[1,1])
            axes[1,1].set_title('Meal Type Volume Patterns')
            axes[1,1].tick_params(axis='x', rotation=45)
        
        # 6. Special Events Impact
        if 'special_event_bool' in self.data.columns:
            self.data.groupby('special_event_bool')['quantity_sold'].mean().plot(kind='bar', ax=axes[1,2])
            axes[1,2].set_title('Special Events Impact')
        
        # 7. Top Cuisines
        if 'cuisine_type' in self.data.columns:
            top_cuisines = self.data.groupby('cuisine_type')['quantity_sold'].sum().nlargest(8)
            top_cuisines.plot(kind='bar', ax=axes[2,0])
            axes[2,0].set_title('Top 8 Cuisines by Volume')
            axes[2,0].tick_params(axis='x', rotation=45)
        
        # 8. Profit Margin vs Quantity
        if 'profit_margin' in self.data.columns:
            axes[2,1].scatter(self.data['profit_margin'], self.data['quantity_sold'], alpha=0.5)
            axes[2,1].set_title('Profit Margin vs Quantity')
            axes[2,1].set_xlabel('Profit Margin (%)')
            axes[2,1].set_ylabel('Quantity Sold')
        
        # 9. Food Categories
        if 'category' in self.data.columns:
            self.data.groupby('category')['quantity_sold'].sum().plot(kind='bar', ax=axes[2,2])
            axes[2,2].set_title('Food Category Volumes')
            axes[2,2].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig('business_logic_validation_original.png', dpi=300, bbox_inches='tight')
        print("Visualizations saved as 'business_logic_validation_original.png'")
        
    def run_all_validations(self):
        """
        Run all business logic validations.
        """
        print("Starting comprehensive business logic validation...")
        print(f"Dataset shape: {self.data.shape}")
        
        # Run all validation checks
        self.validate_restaurant_type_impact()
        self.validate_price_demand_curve()
        self.validate_promotion_impact()
        self.validate_weekend_effect()
        self.validate_meal_type_patterns()
        self.validate_special_events_impact()
        self.validate_cuisine_preferences()
        self.validate_profit_margin_relationship()
        self.validate_food_category_volumes()
        
        # Generate comprehensive report
        report = self.generate_comprehensive_report()
        
        # Create visualizations
        self.create_visualizations()
        
        return report

def main():
    # Use original dataset
    validator = BusinessLogicValidator('cleaned_streamlined_ultimate_malaysian_data.csv')
    report = validator.run_all_validations()
    return report

if __name__ == "__main__":
    main()