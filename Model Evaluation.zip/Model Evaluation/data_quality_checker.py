import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class DataQualityChecker:
    """
    Comprehensive data quality checker for synthetic restaurant demand data.
    Focuses on data cleaning, logical validation, and detailed reporting.
    """
    
    def __init__(self, data_path=None, dataframe=None):
        """
        Initialize the data quality checker.
        
        Args:
            data_path (str): Path to CSV file
            dataframe (pd.DataFrame): DataFrame to check
        """
        if data_path:
            self.df = pd.read_csv(data_path)
        elif dataframe is not None:
            self.df = dataframe.copy()
        else:
            raise ValueError("Either data_path or dataframe must be provided")
        
        self.original_shape = self.df.shape
        self.issues_found = []
        self.cleaned_df = self.df.copy()
        
        print(f"Data Quality Checker Initialized")
        print(f"Original dataset shape: {self.original_shape}")
        print("=" * 80)
    
    def check_missing_values(self):
        """Identify and handle missing values"""
        print("\n1. MISSING VALUES ANALYSIS")
        print("-" * 40)
        
        missing_counts = self.df.isnull().sum()
        missing_percentages = (missing_counts / len(self.df)) * 100
        
        if missing_counts.sum() == 0:
            print("✓ No missing values found in the dataset")
        else:
            print(f"Total missing values: {missing_counts.sum()}")
            print("\nMissing values by column:")
            for col in missing_counts[missing_counts > 0].index:
                count = missing_counts[col]
                percentage = missing_percentages[col]
                print(f"  {col}: {count} ({percentage:.2f}%)")
                
                # Treatment strategy based on column type and missing percentage
                if percentage > 50:
                    print(f"    ⚠️  WARNING: High missing rate for {col} - Consider dropping column")
                    self.issues_found.append(f"High missing rate in {col}: {percentage:.2f}%")
                elif col in ['quantity_sold', 'demand']:
                    print(f"    Treatment: Drop rows (critical target variable)")
                    self.cleaned_df = self.cleaned_df.dropna(subset=[col])
                elif self.df[col].dtype in ['int64', 'float64']:
                    median_val = self.df[col].median()
                    print(f"    Treatment: Fill with median ({median_val})")
                    self.cleaned_df[col].fillna(median_val, inplace=True)
                else:
                    mode_val = self.df[col].mode().iloc[0] if not self.df[col].mode().empty else 'Unknown'
                    print(f"    Treatment: Fill with mode ('{mode_val}')")
                    self.cleaned_df[col].fillna(mode_val, inplace=True)
    
    def check_duplicates(self):
        """
        Detect and remove duplicate records.
        """
        print("\n2. DUPLICATE RECORDS ANALYSIS")
        print("-" * 40)
        
        # Check for exact duplicates
        exact_duplicates = self.df.duplicated().sum()
        print(f"Exact duplicate rows: {exact_duplicates}")
        
        if exact_duplicates > 0:
            print(f"  Treatment: Removing {exact_duplicates} duplicate rows")
            self.cleaned_df = self.cleaned_df.drop_duplicates()
            self.issues_found.append(f"Found and removed {exact_duplicates} duplicate rows")
        else:
            print("✓ No exact duplicate rows found")
        
        # Check for potential logical duplicates (same item, date, restaurant)
        if all(col in self.df.columns for col in ['item_id', 'date', 'restaurant_id']):
            logical_duplicates = self.df.duplicated(subset=['item_id', 'date', 'restaurant_id']).sum()
            print(f"Logical duplicates (same item/date/restaurant): {logical_duplicates}")
            
            if logical_duplicates > 0:
                print(f"  ⚠️  WARNING: Found {logical_duplicates} logical duplicates - Manual review recommended")
                self.issues_found.append(f"Found {logical_duplicates} logical duplicates requiring review")
    
    def detect_outliers(self):
        """
        Identify outliers using IQR method and statistical analysis.
        """
        print("\n3. OUTLIER DETECTION")
        print("-" * 40)
        
        numerical_columns = self.df.select_dtypes(include=[np.number]).columns
        total_outliers = 0
        
        for col in numerical_columns:
            if col in self.df.columns:
                Q1 = self.df[col].quantile(0.25)
                Q3 = self.df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outliers = ((self.df[col] < lower_bound) | (self.df[col] > upper_bound)).sum()
                total_outliers += outliers
                
                if outliers > 0:
                    percentage = (outliers / len(self.df)) * 100
                    print(f"  {col}: {outliers} outliers ({percentage:.2f}%)")
                    print(f"    Range: [{lower_bound:.2f}, {upper_bound:.2f}]")
                    print(f"    Min/Max values: {self.df[col].min():.2f} / {self.df[col].max():.2f}")
                    
                    # Treatment strategy
                    if col in ['quantity_sold', 'demand'] and percentage > 5:
                        print(f"    ⚠️  WARNING: High outlier rate in target variable - Manual review needed")
                        self.issues_found.append(f"High outlier rate in {col}: {percentage:.2f}%")
                    elif percentage > 10:
                        print(f"    Treatment: Cap at bounds (high outlier rate)")
                        self.cleaned_df[col] = np.clip(self.cleaned_df[col], lower_bound, upper_bound)
                    else:
                        print(f"    Treatment: Keep outliers (acceptable rate)")
        
        if total_outliers == 0:
            print("✓ No statistical outliers detected")
        else:
            print(f"\nTotal outliers detected: {total_outliers}")
    
    def check_data_inconsistencies(self):
        """Identify various data inconsistencies."""

        print("\n3. DATA INCONSISTENCY CHECKS")
        print("-" * 40)
        
        inconsistencies = 0
        
        # Check for negative values in quantity/demand columns
        quantity_cols = [col for col in self.df.columns if 'quantity' in col.lower() or 'demand' in col.lower()]
        for col in quantity_cols:
            if col in self.df.columns:
                negative_count = (self.df[col] < 0).sum()
                if negative_count > 0:
                    print(f"  ⚠️  Negative values in {col}: {negative_count}")
                    inconsistencies += negative_count
                    self.issues_found.append(f"Found {negative_count} negative values in {col}")
        
        # Check for price inconsistencies
        price_cols = [col for col in self.df.columns if 'price' in col.lower() or 'cost' in col.lower()]
        for col in price_cols:
            if col in self.df.columns:
                zero_or_negative = (self.df[col] <= 0).sum()
                if zero_or_negative > 0:
                    print(f"  ⚠️  Zero/negative prices in {col}: {zero_or_negative}")
                    inconsistencies += zero_or_negative
                    self.issues_found.append(f"Found {zero_or_negative} zero/negative prices in {col}")
        
        # Check date consistency
        date_cols = [col for col in self.df.columns if 'date' in col.lower()]
        for col in date_cols:
            if col in self.df.columns:
                try:
                    dates = pd.to_datetime(self.df[col], errors='coerce')
                    invalid_dates = dates.isnull().sum()
                    if invalid_dates > 0:
                        print(f"  ⚠️  Invalid dates in {col}: {invalid_dates}")
                        inconsistencies += invalid_dates
                        self.issues_found.append(f"Found {invalid_dates} invalid dates in {col}")
                    
                    # Check for future dates
                    future_dates = (dates > datetime.now()).sum()
                    if future_dates > 0:
                        print(f"  ⚠️  Future dates in {col}: {future_dates}")
                        inconsistencies += future_dates
                        self.issues_found.append(f"Found {future_dates} future dates in {col}")
                except:
                    print(f"  ⚠️  Cannot parse dates in {col}")
                    self.issues_found.append(f"Cannot parse dates in {col}")
        
        if inconsistencies == 0:
            print("✓ No data inconsistencies detected")
        else:
            print(f"\nTotal inconsistencies found: {inconsistencies}")
    
    def validate_logical_relationships(self):
        """
        Verify logical relationships and realistic values.
        """
        print("\n4. LOGICAL VALIDATION")
        print("-" * 40)
        
        validation_issues = 0
        
        # Check quantity sold vs demand relationship
        if 'quantity_sold' in self.df.columns and 'demand' in self.df.columns:
            impossible_sales = (self.df['quantity_sold'] > self.df['demand'] * 1.1).sum()  # Allow 10% buffer
            if impossible_sales > 0:
                print(f"  ⚠️  Quantity sold > demand: {impossible_sales} cases")
                validation_issues += impossible_sales
                self.issues_found.append(f"Found {impossible_sales} cases where quantity sold exceeds demand")
        
        # Check price vs cost relationship
        if 'price' in self.df.columns and 'cost' in self.df.columns:
            negative_margin = (self.df['price'] < self.df['cost']).sum()
            if negative_margin > 0:
                print(f"  ⚠️  Price < cost (negative margin): {negative_margin} cases")
                validation_issues += negative_margin
                self.issues_found.append(f"Found {negative_margin} cases with negative profit margin")
        
        # Validate categorical values
        categorical_cols = self.df.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            unique_values = self.df[col].nunique()
            total_values = len(self.df)
            
            # Check for too many unique values in categorical columns
            if unique_values > total_values * 0.5:
                print(f"  ⚠️  High cardinality in {col}: {unique_values} unique values")
                self.issues_found.append(f"High cardinality in categorical column {col}: {unique_values} unique values")
        
        # Check for realistic quantity ranges
        if 'quantity_sold' in self.df.columns:
            max_quantity = self.df['quantity_sold'].max()
            mean_quantity = self.df['quantity_sold'].mean()
            
            if max_quantity > mean_quantity * 100:  # Extreme outlier check
                print(f"  ⚠️  Extreme quantity values detected (max: {max_quantity}, mean: {mean_quantity:.2f})")
                self.issues_found.append(f"Extreme quantity values: max {max_quantity} vs mean {mean_quantity:.2f}")
        
        if validation_issues == 0:
            print("✓ All logical relationships appear valid")
        else:
            print(f"\nTotal validation issues: {validation_issues}")
    
    def validate_numerical_ranges(self):
        """Validate numerical ranges against real-world expectations."""
        print("\n4. NUMERICAL RANGE VALIDATION")
        print("-" * 40)
        
        range_issues = 0
        
        # Define expected ranges for common restaurant data
        expected_ranges = {
            'quantity_sold': (0, 1000),  # Reasonable daily quantity per item
            'demand': (0, 1000),
            'price': (0.5, 500),  # Restaurant item prices
            'cost': (0.1, 200),   # Cost of goods
            'profit_margin': (0, 1),  # Profit margin as ratio
            'rating': (1, 5),     # Restaurant ratings
            'temperature': (-10, 50),  # Temperature in Celsius
        }
        
        for col, (min_val, max_val) in expected_ranges.items():
            if col in self.df.columns:
                out_of_range = ((self.df[col] < min_val) | (self.df[col] > max_val)).sum()
                if out_of_range > 0:
                    actual_min = self.df[col].min()
                    actual_max = self.df[col].max()
                    print(f"  ⚠️  {col} out of expected range [{min_val}, {max_val}]: {out_of_range} values")
                    print(f"      Actual range: [{actual_min:.2f}, {actual_max:.2f}]")
                    range_issues += out_of_range
                    self.issues_found.append(f"{col} has {out_of_range} values outside expected range")
                else:
                    print(f"  ✓ {col} within expected range [{min_val}, {max_val}]")
        
        if range_issues == 0:
            print("✓ All numerical values within expected ranges")
        else:
            print(f"\nTotal range validation issues: {range_issues}")
    
    def generate_summary_report(self):
        """
        Generate a comprehensive summary report.
        """
        print("\n" + "=" * 80)
        print("DATA QUALITY SUMMARY REPORT")
        print("=" * 80)
        
        print(f"\nOriginal dataset shape: {self.original_shape}")
        print(f"Cleaned dataset shape: {self.cleaned_df.shape}")
        
        rows_removed = self.original_shape[0] - self.cleaned_df.shape[0]
        if rows_removed > 0:
            print(f"Rows removed during cleaning: {rows_removed} ({(rows_removed/self.original_shape[0]*100):.2f}%)")
        
        print(f"\nTotal issues identified: {len(self.issues_found)}")
        
        if self.issues_found:
            print("\nISSUES REQUIRING MANUAL REVIEW:")
            print("-" * 40)
            for i, issue in enumerate(self.issues_found, 1):
                print(f"{i}. {issue}")
        else:
            print("\n✓ No critical issues found - Data quality appears good")
        
        # Data quality score
        total_checks = 6  # Number of check categories
        issues_weight = min(len(self.issues_found), total_checks)
        quality_score = max(0, (total_checks - issues_weight) / total_checks * 100)
        
        print(f"\nDATA QUALITY SCORE: {quality_score:.1f}/100")
        
        if quality_score >= 90:
            print("✓ EXCELLENT - Data is ready for analysis")
        elif quality_score >= 70:
            print("⚠️  GOOD - Minor issues, proceed with caution")
        elif quality_score >= 50:
            print("⚠️  FAIR - Significant issues, cleaning recommended")
        else:
            print("❌ POOR - Major issues, extensive cleaning required")
        
        return self.cleaned_df
    
    def run_comprehensive_check(self):
        """
        Run all data quality checks in sequence.
        """
        print("COMPREHENSIVE DATA QUALITY ANALYSIS")
        print("=" * 80)
        
        # Run all checks
        self.check_missing_values()
        self.check_duplicates()
        self.detect_outliers()
        self.check_data_inconsistencies()
        self.validate_logical_relationships()
        self.validate_numerical_ranges()
        
        # Generate final report
        cleaned_data = self.generate_summary_report()
        
        return cleaned_data


def main():
    """
    Main function to demonstrate the data quality checker.
    """
    # Example usage with the restaurant demand dataset
    try:
        # Try to load the existing dataset
        data_path = "cleaned_streamlined_ultimate_malaysian_data.csv"
        checker = DataQualityChecker(data_path=data_path)
        
        # Run comprehensive quality checks
        cleaned_data = checker.run_comprehensive_check()
        
        # Save cleaned data if significant changes were made
        if checker.original_shape[0] != cleaned_data.shape[0]:
            output_path = "quality_checked_data.csv"
            cleaned_data.to_csv(output_path, index=False)
            print(f"\nCleaned data saved to: {output_path}")
        
    except FileNotFoundError:
        print("Dataset file not found. Creating synthetic data for demonstration...")
        
        # Create synthetic data for demonstration
        np.random.seed(42)
        n_samples = 1000
        
        synthetic_data = {
            'item_id': np.random.randint(1, 101, n_samples),
            'restaurant_id': np.random.randint(1, 21, n_samples),
            'date': pd.date_range('2023-01-01', periods=n_samples, freq='D')[:n_samples],
            'quantity_sold': np.random.poisson(50, n_samples),
            'demand': np.random.poisson(55, n_samples),
            'price': np.random.uniform(5, 50, n_samples),
            'cost': np.random.uniform(2, 25, n_samples),
            'category': np.random.choice(['Main', 'Appetizer', 'Dessert', 'Beverage'], n_samples),
            'rating': np.random.uniform(1, 5, n_samples)
        }
        
        # Introduce some quality issues for demonstration
        synthetic_data['quantity_sold'][::100] = -1  # Negative values
        synthetic_data['price'][::150] = 0  # Zero prices
        synthetic_data['demand'][::200] = np.nan  # Missing values
        
        df = pd.DataFrame(synthetic_data)
        
        # Run quality checks on synthetic data
        checker = DataQualityChecker(dataframe=df)
        cleaned_data = checker.run_comprehensive_check()
        
        print("\nDemonstration completed with synthetic data.")


if __name__ == "__main__":
    main()