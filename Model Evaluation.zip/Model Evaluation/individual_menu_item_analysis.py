#!/usr/bin/env python3
"""
Individual Menu Item Performance Analysis

This script analyzes individual menu items from the dataset to identify
the top 10 performing items with performance scores between 0.7-0.92.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler, LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

class MenuItemAnalyzer:
    def __init__(self, data_path='cleaned_streamlined_ultimate_malaysian_data.csv'):
        """
        Initialize the Menu Item Analyzer
        
        Args:
            data_path (str): Path to the dataset
        """
        self.data_path = data_path
        self.data = None
        self.results = []
        self.encoders = {}
        
    def load_data(self):
        """
        Load and prepare the dataset
        """
        print("Loading dataset...")
        self.data = pd.read_csv(self.data_path)
        print(f"Dataset loaded: {self.data.shape[0]} rows, {self.data.shape[1]} columns")
        
        # Display basic info about menu items
        print(f"\nUnique menu items: {self.data['menu_item_name'].nunique()}")
        print(f"Total records: {len(self.data)}")
        
    def prepare_features(self, item_data):
        """
        Prepare features for a specific menu item
        
        Args:
            item_data (DataFrame): Data for a specific menu item
            
        Returns:
            tuple: (X, y) features and target
        """
        # Select relevant features
        feature_columns = [
            'actual_selling_price', 'typical_ingredient_cost', 'restaurant_type',
            'cuisine_type', 'category', 'day_of_week', 'meal_type', 
            'has_promotion', 'special_event'
        ]
        
        # Check if all columns exist
        available_columns = [col for col in feature_columns if col in item_data.columns]
        
        X = item_data[available_columns].copy()
        y = item_data['quantity_sold'].copy()
        
        # Handle categorical variables
        categorical_columns = ['restaurant_type', 'cuisine_type', 'category', 
                             'day_of_week', 'meal_type']
        
        for col in categorical_columns:
            if col in X.columns:
                if col not in self.encoders:
                    self.encoders[col] = LabelEncoder()
                    X[col] = self.encoders[col].fit_transform(X[col].astype(str))
                else:
                    # Handle unseen categories
                    X[col] = X[col].astype(str)
                    mask = X[col].isin(self.encoders[col].classes_)
                    X.loc[~mask, col] = 'unknown'
                    
                    # Add 'unknown' to encoder if not present
                    if 'unknown' not in self.encoders[col].classes_:
                        self.encoders[col].classes_ = np.append(self.encoders[col].classes_, 'unknown')
                    
                    X[col] = self.encoders[col].transform(X[col])
        
        # Handle boolean columns
        boolean_columns = ['has_promotion', 'special_event']
        for col in boolean_columns:
            if col in X.columns:
                X[col] = X[col].astype(int)
        
        return X, y
    
    def analyze_menu_item(self, menu_item):
        """
        Analyze performance of a specific menu item
        
        Args:
            menu_item (str): Name of the menu item
            
        Returns:
            dict: Performance metrics for the menu item
        """
        # Filter data for this menu item
        item_data = self.data[self.data['menu_item_name'] == menu_item].copy()
        
        if len(item_data) < 10:  # Need minimum samples for reliable analysis
            return None
            
        try:
            # Prepare features
            X, y = self.prepare_features(item_data)
            
            # Split data
            if len(X) < 20:
                # For small datasets, use a smaller test size
                test_size = 0.2
            else:
                test_size = 0.3
                
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=42
            )
            
            # Scale features
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            # Train model
            model = RandomForestRegressor(
                n_estimators=100,
                random_state=42,
                n_jobs=-1
            )
            model.fit(X_train_scaled, y_train)
            
            # Make predictions
            y_pred = model.predict(X_test_scaled)
            
            # Calculate metrics
            r2 = r2_score(y_test, y_pred)
            rmse = np.sqrt(mean_squared_error(y_test, y_pred))
            mae = mean_absolute_error(y_test, y_pred)
            
            # Calculate additional statistics
            avg_quantity = item_data['quantity_sold'].mean()
            std_quantity = item_data['quantity_sold'].std()
            avg_price = item_data['actual_selling_price'].mean()
            total_records = len(item_data)
            
            return {
                'menu_item': menu_item,
                'r2_score': r2,
                'rmse': rmse,
                'mae': mae,
                'avg_quantity': avg_quantity,
                'std_quantity': std_quantity,
                'avg_price': avg_price,
                'total_records': total_records,
                'performance_score': r2  # Using R² as performance metric
            }
            
        except Exception as e:
            print(f"Error analyzing {menu_item}: {str(e)}")
            return None
    
    def analyze_all_items(self):
        """
        Analyze all menu items in the dataset
        """
        print("\nAnalyzing individual menu items...")
        
        unique_items = self.data['menu_item_name'].unique()
        total_items = len(unique_items)
        
        print(f"Total unique menu items to analyze: {total_items}")
        
        for i, item in enumerate(unique_items, 1):
            if i % 50 == 0 or i == total_items:
                print(f"Progress: {i}/{total_items} items analyzed")
                
            result = self.analyze_menu_item(item)
            if result is not None:
                self.results.append(result)
        
        print(f"\nAnalysis complete! {len(self.results)} items successfully analyzed.")
    
    def get_top_performers(self, min_score=0.7, max_score=0.92, top_n=10):
        if not self.results:
            print("No analysis results available. Run analyze_all_items() first.")
            return None
            
        # Convert results to DataFrame
        results_df = pd.DataFrame(self.results)
        
        # Filter by score range
        filtered_df = results_df[
            (results_df['performance_score'] >= min_score) & 
            (results_df['performance_score'] <= max_score)
        ].copy()
        
        if len(filtered_df) == 0:
            print(f"No items found with performance score between {min_score} and {max_score}")
            return None
        
        # Sort by performance score and get top N
        top_performers = filtered_df.nlargest(top_n, 'performance_score')
        
        return top_performers
    
    def display_results(self, top_performers):
        """
        Display the results in a formatted way
        
        Args:
            top_performers (DataFrame): Top performing menu items
        """
        if top_performers is None or len(top_performers) == 0:
            print("No results to display.")
            return
            
        print(f"\n{'='*80}")
        print(f"TOP {len(top_performers)} PERFORMING MENU ITEMS (Score: 0.7 - 0.92)")
        print(f"{'='*80}")
        
        for i, (_, row) in enumerate(top_performers.iterrows(), 1):
            print(f"\n{i}. {row['menu_item']}")
            print(f"   Performance Score (R²): {row['performance_score']:.4f}")
            print(f"   RMSE: {row['rmse']:.2f}")
            print(f"   MAE: {row['mae']:.2f}")
            print(f"   Average Quantity Sold: {row['avg_quantity']:.1f}")
            print(f"   Average Price: ${row['avg_price']:.2f}")
            print(f"   Total Records: {row['total_records']}")
            print(f"   {'-'*50}")
    
    def create_visualization(self, top_performers):
        """
        Create visualizations for the top performers
        
        Args:
            top_performers (DataFrame): Top performing menu items
        """
        if top_performers is None or len(top_performers) == 0:
            return
            
        # Create figure with subplots
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Top 10 Menu Items Performance Analysis (Score: 0.7-0.92)', fontsize=16)
        
        # 1. Performance Score Bar Chart
        axes[0, 0].barh(range(len(top_performers)), top_performers['performance_score'])
        axes[0, 0].set_yticks(range(len(top_performers)))
        axes[0, 0].set_yticklabels([item[:20] + '...' if len(item) > 20 else item 
                                   for item in top_performers['menu_item']], fontsize=8)
        axes[0, 0].set_xlabel('Performance Score (R²)')
        axes[0, 0].set_title('Performance Scores')
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. Average Quantity vs Performance Score
        axes[0, 1].scatter(top_performers['performance_score'], top_performers['avg_quantity'])
        axes[0, 1].set_xlabel('Performance Score (R²)')
        axes[0, 1].set_ylabel('Average Quantity Sold')
        axes[0, 1].set_title('Quantity vs Performance')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Price vs Performance Score
        axes[1, 0].scatter(top_performers['performance_score'], top_performers['avg_price'])
        axes[1, 0].set_xlabel('Performance Score (R²)')
        axes[1, 0].set_ylabel('Average Price ($)')
        axes[1, 0].set_title('Price vs Performance')
        axes[1, 0].grid(True, alpha=0.3)
        
        # 4. RMSE vs Performance Score
        axes[1, 1].scatter(top_performers['performance_score'], top_performers['rmse'])
        axes[1, 1].set_xlabel('Performance Score (R²)')
        axes[1, 1].set_ylabel('RMSE')
        axes[1, 1].set_title('RMSE vs Performance')
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('top_menu_items_analysis.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        print(f"\nVisualization saved as 'top_menu_items_analysis.png'")
    
    def save_results(self, top_performers, filename='top_menu_items_results.csv'):
        """
        Save results to CSV file
        
        Args:
            top_performers (DataFrame): Top performing menu items
            filename (str): Output filename
        """
        if top_performers is not None:
            top_performers.to_csv(filename, index=False)
            print(f"Results saved to '{filename}'")
    
    def run_analysis(self):
        """
        Run the complete analysis pipeline
        """
        # Load data
        self.load_data()
        
        # Analyze all items
        self.analyze_all_items()
        
        # Get top performers in the specified range
        top_performers = self.get_top_performers(min_score=0.7, max_score=0.92, top_n=10)
        
        # Display results
        self.display_results(top_performers)
        
        # Create visualizations
        self.create_visualization(top_performers)
        
        # Save results
        self.save_results(top_performers)
        
        return top_performers

def main():
    """
    Main function to run the menu item analysis
    """
    print("Individual Menu Item Performance Analysis")
    print("=========================================")
    
    # Initialize analyzer
    analyzer = MenuItemAnalyzer()
    
    # Run complete analysis
    results = analyzer.run_analysis()
    
    if results is not None:
        print(f"\nAnalysis completed successfully!")
        print(f"Found {len(results)} menu items with performance scores between 0.7-0.92")
    else:
        print("\nNo items found in the specified performance range.")

if __name__ == "__main__":
    main()