#!/usr/bin/env python3
"""
Baseline Machine Learning Pipeline for Restaurant Demand Forecasting

This script implements a baseline comparison of 5 different machine learning models:
1. Random Forest
2. XGBoost
3. LightGBM
4. CatBoost
5. Linear Regression

All models use default parameters and consistent feature engineering.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import lightgbm as lgb
import catboost as cb
import warnings
import time
from unified_restaurant_demand_system import RestaurantFeatureEngineer

warnings.filterwarnings('ignore')

class BaselineModelPipeline:
    """
    Baseline machine learning pipeline for restaurant demand forecasting.
    Implements 5 different models with default parameters.
    """
    
    def __init__(self, data_path, random_state=42):
        """
        Initialize the baseline pipeline.
        
        Args:
            data_path (str): Path to the dataset
            random_state (int): Random seed for reproducibility
        """
        self.data_path = data_path
        self.random_state = random_state
        self.feature_engineer = RestaurantFeatureEngineer(data_path)
        self.scaler = StandardScaler()
        self.models = {}
        self.results = {}
        
        # Set random seeds for reproducibility
        np.random.seed(random_state)
        
    def prepare_data(self):
        """
        Prepare the dataset with feature engineering.
        
        Returns:
            tuple: X_train, X_test, y_train, y_test
        """
        print("=== DATA PREPARATION ===")
        
        # Load and engineer features
        df = self.feature_engineer.engineer_features_for_existing_items()
        
        # Select features for modeling
        feature_columns = [
            # Historical demand features
            'lag_1_day', 'lag_7_day', 'ma_7_day', 'ma_30_day', 'std_7_day', 'trend_7_day',
            
            # Price features
            'price_gap', 'profit_margin', 'price_to_cost_ratio', 'market_price_ratio', 'price_rank_in_category',
            
            # Categorical features (encoded)
            'category_encoded', 'cuisine_type_encoded', 'meal_type_encoded', 'restaurant_type_encoded',
            'ingredient_count',
            
            # Contextual features
            'day_of_week_num', 'day_sin', 'day_cos', 'month', 'month_sin', 'month_cos',
            'is_weekend', 'weekend_lunch', 'weekend_dinner',
            
            # Restaurant features
            'restaurant_demand_mean', 'restaurant_demand_std',
            
            # Interaction features
            'price_special_event', 'price_promotion', 'price_weekend',
            'category_restaurant_interaction', 'meal_day_interaction'
        ]
        
        # Filter features that exist in the dataset
        available_features = [col for col in feature_columns if col in df.columns]
        print(f"Using {len(available_features)} features for modeling")
        
        # Prepare features and target
        X = df[available_features].fillna(0)
        y = df['demand']
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_state, stratify=None
        )
        
        # Scale features for Linear Regression
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        print(f"Training set: {X_train.shape[0]} samples")
        print(f"Test set: {X_test.shape[0]} samples")
        print(f"Features: {X_train.shape[1]}")
        
        return X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled
    
    def calculate_mape(self, y_true, y_pred):
        """
        Calculate Mean Absolute Percentage Error.
        
        Args:
            y_true: True values
            y_pred: Predicted values
            
        Returns:
            float: MAPE value
        """
        return np.mean(np.abs((y_true - y_pred) / np.maximum(y_true, 1e-8))) * 100
    
    def evaluate_model(self, model, X_train, X_test, y_train, y_test, model_name):
        """
        Evaluate a model and store results.
        
        Args:
            model: Trained model
            X_train, X_test: Training and test features
            y_train, y_test: Training and test targets
            model_name (str): Name of the model
        """
        # Predictions
        y_train_pred = model.predict(X_train)
        y_test_pred = model.predict(X_test)
        
        # Calculate metrics
        train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
        test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
        
        train_mae = mean_absolute_error(y_train, y_train_pred)
        test_mae = mean_absolute_error(y_test, y_test_pred)
        
        train_r2 = r2_score(y_train, y_train_pred)
        test_r2 = r2_score(y_test, y_test_pred)
        
        train_mape = self.calculate_mape(y_train, y_train_pred)
        test_mape = self.calculate_mape(y_test, y_test_pred)
        
        # Store results
        self.results[model_name] = {
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_mae': train_mae,
            'test_mae': test_mae,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_mape': train_mape,
            'test_mape': test_mape,
            'overfitting': train_r2 - test_r2
        }
        
        print(f"\n{model_name} Results:")
        print(f"  Train R²: {train_r2:.4f} | Test R²: {test_r2:.4f}")
        print(f"  Train RMSE: {train_rmse:.4f} | Test RMSE: {test_rmse:.4f}")
        print(f"  Train MAE: {train_mae:.4f} | Test MAE: {test_mae:.4f}")
        print(f"  Train MAPE: {train_mape:.2f}% | Test MAPE: {test_mape:.2f}%")
        print(f"  Overfitting (R² diff): {train_r2 - test_r2:.4f}")
    
    def train_random_forest(self, X_train, X_test, y_train, y_test):
        """
        Train Random Forest model with default parameters.
        """
        print("\n=== TRAINING RANDOM FOREST ===")
        start_time = time.time()
        
        model = RandomForestRegressor(
            random_state=self.random_state,
            n_jobs=-1
        )
        
        model.fit(X_train, y_train)
        training_time = time.time() - start_time
        
        self.models['Random Forest'] = model
        self.evaluate_model(model, X_train, X_test, y_train, y_test, 'Random Forest')
        print(f"  Training time: {training_time:.2f} seconds")
    
    def train_xgboost(self, X_train, X_test, y_train, y_test):
        """
        Train XGBoost model with default parameters.
        """
        print("\n=== TRAINING XGBOOST ===")
        start_time = time.time()
        
        model = xgb.XGBRegressor(
            random_state=self.random_state,
            n_jobs=-1,
            verbosity=0
        )
        
        model.fit(X_train, y_train)
        training_time = time.time() - start_time
        
        self.models['XGBoost'] = model
        self.evaluate_model(model, X_train, X_test, y_train, y_test, 'XGBoost')
        print(f"  Training time: {training_time:.2f} seconds")
    
    def train_lightgbm(self, X_train, X_test, y_train, y_test):
        """
        Train LightGBM model with default parameters.
        """
        print("\n=== TRAINING LIGHTGBM ===")
        start_time = time.time()
        
        model = lgb.LGBMRegressor(
            random_state=self.random_state,
            n_jobs=-1,
            verbosity=-1
        )
        
        model.fit(X_train, y_train)
        training_time = time.time() - start_time
        
        self.models['LightGBM'] = model
        self.evaluate_model(model, X_train, X_test, y_train, y_test, 'LightGBM')
        print(f"  Training time: {training_time:.2f} seconds")
    
    def train_catboost(self, X_train, X_test, y_train, y_test):
        """
        Train CatBoost model with default parameters.
        """
        print("\n=== TRAINING CATBOOST ===")
        start_time = time.time()
        
        model = cb.CatBoostRegressor(
            random_state=self.random_state,
            verbose=False
        )
        
        model.fit(X_train, y_train)
        training_time = time.time() - start_time
        
        self.models['CatBoost'] = model
        self.evaluate_model(model, X_train, X_test, y_train, y_test, 'CatBoost')
        print(f"  Training time: {training_time:.2f} seconds")
    
    def train_linear_regression(self, X_train_scaled, X_test_scaled, X_train, X_test, y_train, y_test):
        """
        Train Linear Regression model with scaled features.
        """
        print("\n=== TRAINING LINEAR REGRESSION ===")
        start_time = time.time()
        
        model = LinearRegression()
        model.fit(X_train_scaled, y_train)
        training_time = time.time() - start_time
        
        self.models['Linear Regression'] = model
        
        # Evaluate with scaled features
        y_train_pred = model.predict(X_train_scaled)
        y_test_pred = model.predict(X_test_scaled)
        
        # Calculate metrics
        train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
        test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
        
        train_mae = mean_absolute_error(y_train, y_train_pred)
        test_mae = mean_absolute_error(y_test, y_test_pred)
        
        train_r2 = r2_score(y_train, y_train_pred)
        test_r2 = r2_score(y_test, y_test_pred)
        
        train_mape = self.calculate_mape(y_train, y_train_pred)
        test_mape = self.calculate_mape(y_test, y_test_pred)
        
        # Store results
        self.results['Linear Regression'] = {
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_mae': train_mae,
            'test_mae': test_mae,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_mape': train_mape,
            'test_mape': test_mape,
            'overfitting': train_r2 - test_r2
        }
        
        print(f"\nLinear Regression Results:")
        print(f"  Train R²: {train_r2:.4f} | Test R²: {test_r2:.4f}")
        print(f"  Train RMSE: {train_rmse:.4f} | Test RMSE: {test_rmse:.4f}")
        print(f"  Train MAE: {train_mae:.4f} | Test MAE: {test_mae:.4f}")
        print(f"  Train MAPE: {train_mape:.2f}% | Test MAPE: {test_mape:.2f}%")
        print(f"  Overfitting (R² diff): {train_r2 - test_r2:.4f}")
        print(f"  Training time: {training_time:.2f} seconds")
    
    def print_comparison_results(self):
        """
        Print a comprehensive comparison of all models.
        """
        print("\n" + "="*80)
        print("MODEL COMPARISON RESULTS")
        print("="*80)
        
        # Create comparison DataFrame
        comparison_df = pd.DataFrame(self.results).T
        
        # Sort by test R²
        comparison_df = comparison_df.sort_values('test_r2', ascending=False)
        
        print("\nRanking by Test R² Score:")
        print("-" * 50)
        for i, (model, row) in enumerate(comparison_df.iterrows(), 1):
            print(f"{i}. {model}: {row['test_r2']:.4f}")
        
        print("\nDetailed Training Metrics Comparison:")
        print("-" * 80)
        print(f"{'Model':<15} {'Train R²':<10} {'Train RMSE':<12} {'Train MAE':<10} {'Train MAPE':<12}")
        print("-" * 80)
        
        for model, row in comparison_df.iterrows():
            print(f"{model:<15} {row['train_r2']:<10.4f} {row['train_rmse']:<12.4f} {row['train_mae']:<10.4f} {row['train_mape']:<12.2f}%")
        
        print("\nDetailed Test Metrics Comparison:")
        print("-" * 80)
        print(f"{'Model':<15} {'Test R²':<10} {'Test RMSE':<12} {'Test MAE':<10} {'Test MAPE':<12} {'Overfitting':<12}")
        print("-" * 80)
        
        for model, row in comparison_df.iterrows():
            print(f"{model:<15} {row['test_r2']:<10.4f} {row['test_rmse']:<12.4f} {row['test_mae']:<10.4f} {row['test_mape']:<12.2f}% {row['overfitting']:<12.4f}")
        
        # Best model analysis
        best_model = comparison_df.index[0]
        best_r2 = comparison_df.loc[best_model, 'test_r2']
        
        print(f"\nBest Performing Model: {best_model}")
        print(f"Test R² Score: {best_r2:.4f}")
        
        # Overfitting analysis
        print("\nOverfitting Analysis (Train R² - Test R²):")
        print("-" * 40)
        overfitting_sorted = comparison_df.sort_values('overfitting')
        for model, row in overfitting_sorted.iterrows():
            overfitting_status = "Good" if row['overfitting'] < 0.1 else "Moderate" if row['overfitting'] < 0.2 else "High"
            print(f"{model:<15}: {row['overfitting']:<8.4f} ({overfitting_status})")
    
    def run_baseline_pipeline(self):
        """
        Run the complete baseline pipeline.
        """
        print("BASELINE MACHINE LEARNING PIPELINE FOR RESTAURANT DEMAND FORECASTING")
        print("=" * 80)
        
        # Prepare data
        X_train, X_test, y_train, y_test, X_train_scaled, X_test_scaled = self.prepare_data()
        
        # Train all models
        self.train_random_forest(X_train, X_test, y_train, y_test)
        self.train_xgboost(X_train, X_test, y_train, y_test)
        self.train_lightgbm(X_train, X_test, y_train, y_test)
        self.train_catboost(X_train, X_test, y_train, y_test)
        self.train_linear_regression(X_train_scaled, X_test_scaled, X_train, X_test, y_train, y_test)
        
        # Print comparison results
        self.print_comparison_results()
        
        return self.models, self.results

def main():
    """
    Main function to run the baseline pipeline.
    """
    # Initialize pipeline
    data_path = "modified_cleaned_streamlined_ultimate_malaysian_data.csv"
    pipeline = BaselineModelPipeline(data_path, random_state=42)
    
    # Run pipeline
    models, results = pipeline.run_baseline_pipeline()
    
    print("\nBaseline pipeline completed successfully!")
    print("All models trained and evaluated with default parameters.")

if __name__ == "__main__":
    main()